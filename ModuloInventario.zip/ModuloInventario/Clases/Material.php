<?php
require_once '../Clases/Conexion.php';
class Material{
    private $codigoM;
    private $nombreM;
    private $categoriaM;
    private $proveedorM;
    private $stockM;
    private $almacenM;
    private $ubicacionM;
    private $preciocompraM;


    public function __construct($codigoM, $nombreM, $categoriaM,$proveedorM,$stockM, $almacenM, $ubicacionM, $preciocompraM) {
        $this->codigoM = $codigoM;
        $this->nombreM = $nombreM;
        $this->categoriaM=$categoriaM;
        $this->proveedorM=$proveedorM;
        $this->stockM=$stockM;
        $this->almacenM = $almacenM;
        $this->ubicacionM = $ubicacionM;
        $this->preciocompraM=$preciocompraM;
    }

    public function call_registrar_Material() {
        $conexion = Conexion::abrirConexion();
        $query1 = "call sp_verificarMaterial($this->codigoM);";
        $resultado = $conexion->query($query1);
        
        while ($conexion->next_result()) {} // Liberar los resultados de la consulta anterior
        
        if ($resultado->num_rows > 0) {
            $resultado->free(); // Liberar los resultados de la consulta actual
            echo '
            <script>
            alert("Este codigo ya esta registrado, Intenta con otro diferente");
            window.location = "";
            </script>
            ';
            exit();
            
        } else {
            $resultado->free(); // Liberar los resultados de la consulta actual
            $query2 = "call sp_registro_material($this->codigoM,'$this->nombreM',$this->categoriaM,0,$this->proveedorM,$this->almacenM,'$this->ubicacionM',$this->preciocompraM);";
            $conexion->query($query2);
            $conexion->close();
            echo '
                <script>
                alert("Registro Exitoso");
                window.location = "";
                </script>
                ';
            exit();
        }
    }



    public function call_filtro_Material(){
        require_once 'conexion.php';
        $conexion = Conexion::abrirConexion();
        
        $query="CALL sp_filtrolistamateriales($this->codigoM,'$this->nombreM','$this->categoriaM','$this->proveedorM','$this->almacenM','$this->ubicacionM');";
        $resultado = $conexion->query($query);
        $datos = array();
            if ($resultado->num_rows > 0) {
                while ($fila = $resultado->fetch_assoc()) {
                    $datos[] = $fila;
                }
            }
            return $datos;
    }


    public function call_tabla_Material(){
        $conexion = Conexion::abrirConexion();
        $query="call sp_verlistamateriales();";
        $resultado = $conexion->query($query);
        $datos = array();
            if ($resultado->num_rows > 0) {
                while ($fila = $resultado->fetch_assoc()) {
                    $datos[] = $fila;
                }
            }
            return $datos;
    }

    public function call_tablaReabasteciminto_Material(){
        $conexion = Conexion::abrirConexion();
        $query="call sp_verlistareabastecimientomateriales();";
        $resultado = $conexion->query($query);
        $datos = array();
            if ($resultado->num_rows > 0) {
                while ($fila = $resultado->fetch_assoc()) {
                    $datos[] = $fila;
                }
            }
            return $datos;
    }

    public function call_ingresar_stock(){
        $conexion = Conexion::abrirConexion();
        $query="call sp_ingresarstockmaterial($this->codigoM, $this->stockM);";
        $conexion->query($query);
        $conexion->close();
        echo '
        <script>
        alert("Ingreso exitoso");
        window.location = "";
        </script>
        ';
        exit();
    }

    public function call_tabla_Material_Almacen(){
        $conexion = Conexion::abrirConexion();
        $query="call sp_verlistamateriales_almacen();";
        $resultado = $conexion->query($query);
        $conexion->next_result();
        $datos = array();
            if ($resultado->num_rows > 0) {
                while ($fila = $resultado->fetch_assoc()) {
                    $datos[] = $fila;
                }
            }
            return $datos;
    }
}
?>