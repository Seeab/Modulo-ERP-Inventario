<?php
require_once '../Clases/Conexion.php';

class Almacen{
    private $id_almacen;
    private $codigo;
    private $ubicacion;

    public function __construct($id_almacen, $codigo,$ubicacion) {
        $this->id_almacen = $id_almacen;
        $this->codigo = $codigo;
        $this->ubicacion = $ubicacion;
    }

    public function call_cambio_almacen_producto(){
        $conexion = Conexion::abrirConexion();
        $query = "CALL sp_GestAlmc_producto('$this->id_almacen', '$this->codigo','$this->ubicacion')";
        $conexion->query($query);
    
        $conexion->close();
    }

    public function call_cambio_almacen_material(){
        $conexion = Conexion::abrirConexion();
        $query = "CALL sp_GestAlmc_material('$this->id_almacen', '$this->codigo','$this->ubicacion')";
        $conexion->query($query);
    
        $conexion->close();
    }

    public function call_cambio_almacen_insumo(){
        $conexion = Conexion::abrirConexion();
        $query = "CALL sp_GestAlmc_insumo('$this->id_almacen', '$this->codigo','$this->ubicacion')";
        $conexion->query($query);
    
        $conexion->close();
    }
}
?>