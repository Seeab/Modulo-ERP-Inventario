<?php 
class Conexion {
    private static $conexion;

    public static function abrirConexion() {
        $host = "localhost";
        $usuario="root";
        $pass="1234";
        $DB="sistema_erp_inventario";

        if (!isset(self::$conexion)) {
            self::$conexion = new mysqli($host, $usuario, $pass, $DB);
            if (self::$conexion->connect_error){
                die("error en la conexion: " . self::$conexion->connect_error);
            }
            self::$conexion->set_charset("utf8");
        }
        return self::$conexion;
    }
}
?>