<?php
require_once '../Clases/Conexion.php';

class Proveedor
{
    public function obtenerArticulosPorProveedor()
    {
        $conexion = Conexion::abrirConexion();
        $query = "CALL sp_ObtenerArticulosPorProveedor()";
        $resultado = $conexion->query($query);

        if ($resultado->num_rows > 0) {
            $proveedores = array();

            while ($fila = $resultado->fetch_assoc()) {
                $proveedor = $fila['razon_social'];
                if (!array_key_exists($proveedor, $proveedores)) {
                    $proveedores[$proveedor] = array();
                }
                $proveedores[$proveedor][] = $fila;
            }

            $conexion->close();
            return $proveedores;
        }

        $conexion->close();
        return null;
    }
}
?>