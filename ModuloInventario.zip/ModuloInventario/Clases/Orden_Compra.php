<?php
 require_once '../Clases/Conexion.php';
class Orden_Compra{
    private $codigo;
    private $cantidad;
    private $fechaInicio;
    private $fechaTermino;

public function setCodigo($codigo){
    $this->codigo=$codigo;
}
public function setCantidad($cantidad){
    $this->cantidad=$cantidad;
}
public function setFechaInicio($fechaInicio){
    $this->fechaInicio=$fechaInicio;
}
public function setFechaTermino($fechaTermino){
    $this->fechaTermino=$fechaTermino;
}


public function call_crear_orden_compra_producto(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_crear_orden_compra_producto();";
    $conexion->query($query);
    $conexion->close();
}
public function call_crear_orden_compra_material(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_crear_orden_compra_material();";
    $conexion->query($query);
    $conexion->close();
}
public function call_crear_orden_compra_insumo(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_crear_orden_compra_insumo();";
    $conexion->query($query);
    $conexion->close();
}

public function call_ingresar_producto_orden_compra(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_ingresar_producto_orden_compra($this->codigo,$this->cantidad);";
    $conexion->query($query);
    $conexion->close();
}

public function call_ingresar_material_orden_compra(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_ingresar_material_orden_compra($this->codigo,$this->cantidad);";
    $conexion->query($query);
    $conexion->close();
}

public function call_ingresar_insumo_orden_compra(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_ingresar_insumo_orden_compra($this->codigo,$this->cantidad);";
    $conexion->query($query);
    $conexion->close();
}

public function call_tabla_OC_pendiente(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_verlistaOCPendiente()";
    $resultado = $conexion->query($query);
    $datos = array();
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $datos[] = $fila;
            }
        }
        return $datos;
}

public function call_recepcion_OC(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_recepcion_OC($this->codigo);";
    $conexion->query($query);
}

public function call_VerResumenCostos(){
    $conexion = Conexion::abrirConexion();
    $fechaInicio = date('Y-m-d', strtotime($this->fechaInicio));
    $fechaTermino = date('Y-m-d', strtotime($this->fechaTermino));
    $query = "CALL sp_verResumenCostos('$fechaInicio', '$fechaTermino');";
    $resultado=$conexion->query($query);
    $datos = array();
    if ($resultado->num_rows > 0) {
        while ($fila = $resultado->fetch_assoc()) {
            $datos[] = $fila;
        }
    }
    $resultado->free_result(); // Liberar el conjunto de resultados
    while ($conexion->next_result()) { // Avanzar a la siguiente consulta
        if ($resultado = $conexion->store_result()) {
            $resultado->free(); // Liberar los resultados adicionales
        }
    }
    return $datos;
}
public function call_VerTotalCostos(){
    $conexion = Conexion::abrirConexion();
    $fechaInicio = date('Y-m-d', strtotime($this->fechaInicio));
    $fechaTermino = date('Y-m-d', strtotime($this->fechaTermino));

    $query = "CALL sp_verTotalCostos('$fechaInicio', '$fechaTermino');";
    $resultado=$conexion->query($query);
    $datos = array();
    if ($resultado->num_rows > 0) {
        while ($fila = $resultado->fetch_assoc()) {
            $datos[] = $fila;
        }
    }
    $resultado->free_result(); // Liberar el conjunto de resultados
    while ($conexion->next_result()) { // Avanzar a la siguiente consulta
        if ($resultado = $conexion->store_result()) {
            $resultado->free(); // Liberar los resultados adicionales
        }
    }
    return $datos;
}

public function obtenerFechasMinMax() {
    $conexion = Conexion::abrirConexion();
    $query = "CALL sp_obtenerFechasMinMax(@min_fecha, @max_fecha)";
    $conexion->query($query);
    $resultado = $conexion->query("SELECT @min_fecha AS min_fecha, @max_fecha AS max_fecha");
    $datos = $resultado->fetch_assoc();
    $fechaMinima = $datos['min_fecha'];
    $fechaMaxima = $datos['max_fecha'];
    return array($fechaMinima, $fechaMaxima);
}
}
?>