<?php
require_once '../Clases/Conexion.php';
class Insumo{
    private $codigoI;
    private $nombreI;
    private $categoriaI;
    private $proveedorI;
    private $stockI;
    private $almacenI;
    private $ubicacionI;
    private $preciocompraI;


public function __construct($codigoI, $nombreI, $categoriaI,$proveedorI, $stockI, $almacenI, $ubicacionI, $preciocompraI) {
    $this->codigoI = $codigoI;
    $this->nombreI = $nombreI;
    $this->categoriaI=$categoriaI;
    $this->proveedorI=$proveedorI;
    $this->stockI=$stockI;
    $this->almacenI = $almacenI;
    $this->ubicacionI = $ubicacionI;
    $this->preciocompraI=$preciocompraI;
}

public function call_registrar_Insumo(){
    $conexion = Conexion::abrirConexion();
    $query1 = "call sp_verificarInsumo($this->codigoI);";
    $resultado = $conexion->query($query1);
    while ($conexion->next_result()) {} // Liberar los resultados de la consulta anterior

    if ($resultado->num_rows > 0) {
        $resultado->free_result();
        echo '
        <script>
        alert("Este codigo ya esta registrado, Intenta con otro diferente");
        window.location = "";
        </script>
        ';
        exit();
    } else {
    $resultado->free_result();
    $query="call sp_registrar_Insumo($this->codigoI,'$this->nombreI',$this->categoriaI,0,$this->proveedorI,$this->almacenI,'$this->ubicacionI',$this->preciocompraI);";
    $conexion->query($query);
    $conexion->close();
    echo '
    <script>
    alert("Registro Exitoso");
    window.location = "";
    </script>
    ';
    exit();
}
}

public function call_tablaReabasteciminto_Insumo(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_verlistareabastecimientoinsumos();;";
    $resultado = $conexion->query($query);
    $datos = array();
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $datos[] = $fila;
            }
        }
        return $datos;
}

public function call_ingresar_stock(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_ingresarstockinsumo($this->codigoI, $this->stockI);";
    $resultado = $conexion->query($query);
    $conexion->close();
    echo '
    <script>
    alert("Ingreso exitoso");
    window.location = "";
    </script>
    ';
    exit();
}

public function call_filtro_Insumo(){
    $conexion = Conexion::abrirConexion();
    $query="CALL sp_filtrolistainsumos($this->codigoI,'$this->nombreI','$this->categoriaI','$this->proveedorI','$this->almacenI','$this->ubicacionI');";
    $resultado = $conexion->query($query);
    $datos = array();
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $datos[] = $fila;
            }
        }
        return $datos;
}

public function call_tabla_Insumo(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_verlistainsumos();";
    $resultado = $conexion->query($query);
    $datos = array();
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $datos[] = $fila;
            }
        }
        return $datos;
}

public function call_tabla_Insumo_Almacen(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_verlistainsumos_almacen();";
    $resultado = $conexion->query($query);
    $conexion->next_result();
    $datos = array();
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $datos[] = $fila;
            }
        }
        return $datos;
}
}
?>