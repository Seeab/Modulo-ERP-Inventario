<?php
require_once '../Clases/Conexion.php';
class Despacho{
    private $ID_Despacho;


    public function setDespacho($ID_Despacho){
        $this->ID_Despacho=$ID_Despacho;
    }


public function call_sp_despacho(){
    $conexion = Conexion::abrirConexion();
    $query="CALL sp_despacho($this->ID_Despacho,'Despachado');";
    $resultado = $conexion->query($query);
    $conexion->next_result();
    $datos = array();
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $datos[] = $fila;
            }
        }
        return $datos;
}


public function call_tabla_despacho(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_listadespachos();";
    $resultado = $conexion->query($query);
    $conexion->next_result();
    $datos = array();
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $datos[] = $fila;
            }
        }
        return $datos;
}

public function call_tabla_despacho2(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_listadespachos2();";
    $resultado = $conexion->query($query);
    $conexion->next_result();
    $datos = array();
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $datos[] = $fila;
            }
        }
        return $datos;
}
}