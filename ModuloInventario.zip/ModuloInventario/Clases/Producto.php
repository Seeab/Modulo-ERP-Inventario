<?php
require_once '../Clases/Conexion.php';
class Producto{
    private $codigoP;
    private $nombreP;
    private $categoriaP;
    private $proveedorP;
    private $stockP;
    private $almacenP;
    private $ubicacionP;
    private $precioventaP;
    private $preciocompraP;
    


public function __construct($codigoP, $nombreP, $categoriaP,$proveedorP,$stockP, $almacenP, $ubicacionP, $precioventaP, $preciocompraP) {
    $this->codigoP = $codigoP;
    $this->nombreP = $nombreP;
    $this->categoriaP=$categoriaP;
    $this->proveedorP=$proveedorP;
    $this->stockP=$stockP;
    $this->almacenP = $almacenP;
    $this->ubicacionP = $ubicacionP;
    $this->precioventaP=$precioventaP;
    $this->preciocompraP=$preciocompraP;
}


public function call_registrar_Producto() {
    $conexion = Conexion::abrirConexion();
    $query1 = "call sp_verificarProducto($this->codigoP);";
    $resultado = $conexion->query($query1);
    
     
    while ($conexion->next_result()) {} 
    if ($resultado->num_rows > 0) {
        $resultado->free_result();
        echo '
        <script>
        alert("Este codigo ya esta registrado, Intenta con otro diferente");
        window.location = "";
        </script>
        ';
        exit();
    } else {
        $resultado->free_result();
        $query2 = "call sp_registrar_Producto($this->codigoP,'$this->nombreP',$this->categoriaP,0,$this->proveedorP,$this->almacenP,'$this->ubicacionP',$this->precioventaP,$this->preciocompraP);";
        $conexion->query($query2);
        $conexion->close();
        echo '
        <script>
        alert("Registro Exitoso");
        window.location = "";
        </script>
        ';
        exit();
    }
}

public function call_tablaReabastecimiento_Producto(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_verlistareabastecimientoproductos();";
    $resultado = $conexion->query($query);
    $datos = array();
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $datos[] = $fila;
            }
        }
        return $datos;
}

public function call_ingresar_stock(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_ingresarstockproducto($this->codigoP, $this->stockP);";
    $resultado = $conexion->query($query);
    $conexion->close();
    echo '
    <script>
    alert("Ingreso exitoso");
    window.location = "";
    </script>
    ';
    exit();
}

public function call_filtro_Producto(){

    $conexion = Conexion::abrirConexion();
    
    $query="CALL sp_filtrolistaproductos($this->codigoP,'$this->nombreP','$this->categoriaP','$this->proveedorP','$this->almacenP','$this->ubicacionP');";
    $resultado = $conexion->query($query);
    $datos = array();
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $datos[] = $fila;
            }
        }
        return $datos;
}

public function call_tabla_Producto(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_verlistaproductos();";
    $resultado = $conexion->query($query);
    $datos = array();
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $datos[] = $fila;
            }
        }
        return $datos;
}

public function call_tabla_Producto_Almacen(){
    $conexion = Conexion::abrirConexion();
    $query="call sp_verlistaproductos_almacen()";
    $resultado = $conexion->query($query);
    $conexion->next_result();
    $datos = array();
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $datos[] = $fila;
            }
        }
        return $datos;
}
}
?>