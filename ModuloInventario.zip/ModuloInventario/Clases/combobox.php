<?php 
require_once '../Clases/Conexion.php';
class Combobox
{
 
    public function cmb_producto()
    {
        $conexion = Conexion::abrirConexion();
        $query = 'CALL sp_cmbproducto();';
        $resultado = $conexion->query($query);

        if ($resultado !== false) {
            $producto = $resultado->fetch_all(MYSQLI_ASSOC);
            $conexion->next_result();
            return $producto;
        }
        return null;
    }

    public function cmb_material()
    {
        $conexion = Conexion::abrirConexion();
        $query = 'CALL sp_cmbmaterial();';
        $resultado = $conexion->query($query);
        
        if ($resultado !== false) {
            $material = $resultado->fetch_all(MYSQLI_ASSOC);
            $conexion->next_result();
            
            return $material;
        }
        
        return null;
    }

    public function cmb_insumo()
    {
        $conexion = Conexion::abrirConexion();
        $query = 'CALL sp_cmbinsumo();';
        $resultado = $conexion->query($query);

        if ($resultado !== false) {
            $insumo = $resultado->fetch_all(MYSQLI_ASSOC);
            $conexion->next_result();
            
            return $insumo;
        }
        
        return null;
    }

    public function cmb_categoria_producto()
    {
        $conexion = Conexion::abrirConexion();
        $query = 'CALL sp_cmbcategoria_producto();';
        $resultado = $conexion->query($query);
        
        if ($resultado !== false) {
            $categoriaproducto = $resultado->fetch_all(MYSQLI_ASSOC);
            $conexion->next_result();
            
            return $categoriaproducto;
        }
        
        return null;
    }

    public function cmb_categoria_material()
    {
        $conexion = Conexion::abrirConexion();
        $query = 'CALL sp_cmbcategoria_material();';
        $resultado = $conexion->query($query);
        
        if ($resultado !== false) {
            $categoriamaterial = $resultado->fetch_all(MYSQLI_ASSOC);
            $conexion->next_result();

            return $categoriamaterial;
        }
        return null;
    }

    public function cmb_categoria_insumo()
    {
        $conexion = Conexion::abrirConexion();
        $query = 'CALL sp_cmbcategoria_insumo();';
        $resultado = $conexion->query($query);
        
        if ($resultado !== false) {
            $categoriainsumo = $resultado->fetch_all(MYSQLI_ASSOC);
            $conexion->next_result();
            
            return $categoriainsumo;
        }
        
        return null;
    }

    public function cmb_Almacen()
    {
        $conexion = Conexion::abrirConexion();
        $query = 'CALL sp_cmbAlmacen();';
        $resultado = $conexion->query($query);
        
        if ($resultado !== false) {
            $almacen = $resultado->fetch_all(MYSQLI_ASSOC);
            $conexion->next_result();
            
            return $almacen;
        }
        return null;
    }

    public function cmb_Proveedor()
    {
        $conexion = Conexion::abrirConexion();
        $query = 'CALL sp_cmbProveedor();';
        $resultado = $conexion->query($query);
        
        if ($resultado !== false) {
            $proveedor = $resultado->fetch_all(MYSQLI_ASSOC);
            $conexion->next_result();
            
            return $proveedor;
        }
        return null;
    }

    public function cmb_OrdenCompra()
    {
        $conexion = Conexion::abrirConexion();
        $query = 'CALL sp_cmbOrdencompra();';
        $resultado = $conexion->query($query);
        
        if ($resultado !== false) {
            $ordencompra = $resultado->fetch_all(MYSQLI_ASSOC);
            $conexion->next_result();
            
            return $ordencompra;
        }
        return null;
    }

    public function cmb_Despacho()
    {
        $conexion = Conexion::abrirConexion();
        $query = 'call sp_cmbdespacho();';
        $resultado = $conexion->query($query);
        
        if ($resultado !== false) {
            $despacho = $resultado->fetch_all(MYSQLI_ASSOC);
            $conexion->next_result();
            
            return $despacho;
        }
        return null;
    }

    public function cmb_CerrarConexion()
    {
        $conexion = Conexion::abrirConexion();
        $conexion->close();
    }

}
?>