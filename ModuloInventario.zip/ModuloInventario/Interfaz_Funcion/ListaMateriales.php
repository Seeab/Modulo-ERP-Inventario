<?php
require_once '../Clases/material.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigoM = $_POST["codigomaterial"] !== "" ? $_POST["codigomaterial"] : "null";
    $nombreM = $_POST["nombrematerial"] !== "" ? $_POST["nombrematerial"] : "null";
    $categoriaM = $_POST["categoriamaterial"] !== "" ? $_POST["categoriamaterial"] : "null";
    $proveedorM = $_POST["proveedor"] !== "" ? $_POST["proveedor"] : "null";
    $almacenM = $_POST["almacen"] !== "" ? $_POST["almacen"] : "null";
    $ubicacionM = $_POST["ubicacion"] !== "" ? $_POST["ubicacion"] : "null";

    $material = new Material($codigoM, $nombreM, $categoriaM, $proveedorM,null, $almacenM, $ubicacionM, "null");

    if ($codigoM === "null" && $nombreM === "null" && $categoriaM === "null" && $proveedorM === "null" && $almacenM === "null" && $ubicacionM === "null") {
        $tabla = $material->call_tabla_Material();
    } else {
        $tabla = $material->call_filtro_Material();
    }
} else {
    $material = new Material("null", "null", "null", "null",null, "null", "null", "null");
    $tabla = $material->call_tabla_Material();
}
?>


<!DOCTYPE html>
<html>
    <html lang="es">
        <head>
            <meta charset="utf-8">
            <link rel="stylesheet" href="../CSS/sistema_erp.css">
            <title>Lista Materiales</title>
            
        </head>
        <header>
    <nav>
        <ul>
        <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Menú Inventario</a></li>
            <li><a class="menuitem active" href="../Interfaz_Menu/gestionmateriales.php">Volver</a></li>
            
        <ul>
    </nav>
    <h3>Lista Materiales</h3> 
</header>
<body>
<div>
        <div >
            <div>
                <form method="POST" class="formulario">
                  
                  <input class="input-tabla" type="text" placeholder="Codigo" name="codigomaterial"  >
                  <input class="input-tabla" type="text" placeholder="Nombre" name="nombrematerial"  >
                  <input class="input-tabla" type="text" placeholder="Categoria" name="categoriamaterial"  >
                  <input class="input-tabla" type="text" placeholder="Proveedor" name="proveedor" >
                  <input class="input-tabla" type="text" placeholder="Almacen" name="almacen"  >
                  <input class="input-tabla" type="text" placeholder="Ubicacion" name="ubicacion"  >
                  <button class="boton-lista" type="submit" >Filtrar Material</button>
                </form>
            </div>
        </div>
</div>
<br>
<br>
<div >
    <table>
    <tr>
        <th>Codigo Material</th>
        <th>Nombre</th>
        <th>Categoria</th>
        <th>Stock</th>
        <th>Proveedor</th>
        <th>Almacen</th>
        <th>Ubicacion</th>
        <th>Precio Compra</th>
    </tr>
    <?php foreach ($tabla as $fila){ ?>
        <tr>
            <td><?php echo $fila['Codigo']; ?></td>
            <td><?php echo $fila['NombreMaterial']; ?></td>
            <td><?php echo $fila['Categoria']; ?></td>
            <td><?php echo $fila['Stock']; ?></td>
            <td><?php echo $fila['Proveedor']; ?></td>
            <td><?php echo $fila['Almacen']; ?></td>
            <td><?php echo $fila['Ubicacion']; ?></td>
            <td><?php echo $fila['PrecioCompra']; ?></td>
        </tr>
    <?php } ?>
    </table>
</div>

</body>
</html>