<?php
require_once '../Clases/material.php';
    $material = new Material("null", "null", "null", "null",10, "null", "null", "null");
    $tabla = $material->call_tablaReabasteciminto_Material();

?>
<!DOCTYPE html>
<html>
    <html lang="es">
<head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../CSS/sistema_erp.css">
        <title>Lista Reabastecimiento Materiales</title>
</head>
<header>
        <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/ListasReabastecimiento.php">Volver</a></li>
        <ul>
    </nav>
</header>
<body>
<div >
<h2>Lista Reabastecimiento Materiales</h2> 
<label>Bajo de 10 de stock</label>
    <table>
    <tr>
        <th>Codigo Material</th>
        <th>Nombre</th>
        <th>Categoria</th>
        <th>Stock</th>
        <th>Proveedor</th>
        <th>Almacen</th>
        <th>Ubicacion</th>
    </tr>
    <?php foreach ($tabla as $fila){ ?>
        <tr>
            <td><?php echo $fila['CodigoMaterial']; ?></td>
            <td><?php echo $fila['Material']; ?></td>
            <td><?php echo $fila['Categoria']; ?></td>
            <td><?php echo $fila['Stock']; ?></td>
            <td><?php echo $fila['Proveedor']; ?></td>
            <td><?php echo $fila['Almacen']; ?></td>
            <td><?php echo $fila['Ubicacion']; ?></td>
        </tr>
    <?php } ?>
    </table>
</div>
</body>
</html>