<?php 
require_once "../Clases/combobox.php";
require_once '../Clases/Orden_Compra.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["material"]) || isset($_POST["cantidad"])) {

        $orden_compra = new Orden_Compra();
        $codigo = $_POST["material"];
        $cantidad = $_POST["cantidad"];
       

        $orden_compra->setCodigo($codigo);
        $orden_compra->setCantidad($cantidad);
        

        $orden_compra->call_ingresar_material_orden_compra();
    } else {
        $orden_compra = new Orden_Compra();
        $orden_compra->call_crear_orden_compra_material();
    }

}else{
    $combobox= new combobox();
    $material=$combobox->cmb_material();
    $combobox->cmb_CerrarConexion();
}
?>


<!DOCTYPE html>
<html>
<html lang="es">
<head>
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <meta charset="utf-8">
    <title>Orden Compra Material</title>
    <script>
        function enviarForm1() {
            var formulario = document.getElementById("Form1");
            var datosFormulario = new FormData(formulario);

            var xhr = new XMLHttpRequest();
            xhr.open("POST", "Crear_Orden_Compra_Material.php", true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // La solicitud se completó con éxito
                    // Puedes realizar alguna acción adicional aquí si es necesario
                    mostrarForm2();
                }
            };
            xhr.send(datosFormulario);
        }

        function enviarForm2() {
            var formulario = document.getElementById("Form2");
            var datosFormulario = new FormData(formulario);

            var xhr = new XMLHttpRequest();
            xhr.open("POST", "Crear_Orden_Compra_Material.php", true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // La solicitud se completó con éxito
                    // Puedes realizar alguna acción adicional aquí si es necesario
                limpiarCampos();
                mostrarForm2();
                }
            };
            xhr.send(datosFormulario);
        }

        function limpiarCampos() {
           
            document.getElementById("cantidad").value = "";
            document.getElementById("Form2").reset();
        }

        function mostrarForm2() {
            // Ocultar el primer formulario
            document.getElementById("Formulario1").style.display = "none";

            // Mostrar el segundo formulario
            document.getElementById("Formulario2").style.display = "block";
        }
    </script>
</head>
<header>

</header>

<body>
<div id="Formulario1">
<nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Menú Inventario</a></li>
            <li><a class="menuitem active" href="../Interfaz_Menu/Gestion_Orden_Compra.php">Volver a Orden Compra</a></li>
        <ul>
    </nav>
    <div id="contenedor">
        <div id="centroregistro">
            <div class="login_registro">
            <h2>Crear Orden Compra Material</h2>
                <form id="Form1" method="POST">
                <button type="button" class="boton" onclick="enviarForm1()">Seleccionar Materiales</button>
                </form>
            </div>
        </div>
    </div>
</div>
<div id="Formulario2" style="display: none;">
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/Gestion_Orden_Compra.php">Terminar Orden Compra</a></li>
        <ul>
    </nav>
    <div id="contenedor">
        <div id="centroregistro">
            <div class="login_registro">
                <h1>Seleccione Materiales</h1>
                    <form id="Form2" method="POST">
                    <select class="select" id="cmbOpciones" name="material" class="select">
                                <option selected disabled>Seleccione un material</option>
                            <?php foreach ($material as $r) { ?>
                                <option  value="<?php echo $r['codigo_material']; ?>"><?php echo $r['nombre_material']; ?></option>
                            <?php } ?>
                    <input class="input-form" type="number" name="cantidad" placeholder="Cantidad" id="cantidad" min="1" required><br>
                    <button type="button" class="boton" onclick="enviarForm2()">Ingresar</button>
                    </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>