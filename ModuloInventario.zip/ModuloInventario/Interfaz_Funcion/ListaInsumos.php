<?php
require_once '../Clases/Insumo.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigoI = $_POST["codigoinsumo"] !== "" ? $_POST["codigoinsumo"] : "null";
    $nombreI = $_POST["nombreinsumo"] !== "" ? $_POST["nombreinsumo"] : "null";
    $categoriaI = $_POST["categoriainsumo"] !== "" ? $_POST["categoriainsumo"] : "null";
    $proveedorI = $_POST["proveedor"] !== "" ? $_POST["proveedor"] : "null";
    $almacenI = $_POST["almacen"] !== "" ? $_POST["almacen"] : "null";
    $ubicacionI = $_POST["ubicacion"] !== "" ? $_POST["ubicacion"] : "null";

    $insumo = new Insumo($codigoI, $nombreI, $categoriaI, $proveedorI,null, $almacenI, $ubicacionI, "null");

    if ($codigoI === "null" && $nombreI === "null" && $categoriaI === "null" && $proveedorI === "null" && $almacenI === "null" && $ubicacionI === "null") {
        $tabla = $insumo->call_tabla_Insumo();
    } else {
        $tabla = $insumo->call_filtro_Insumo();
    }
} else {
    $insumo = new Insumo("null", "null", "null", "null",null, "null", "null", "null");
    $tabla = $insumo->call_tabla_Insumo();
}
?>


<!DOCTYPE html>
<html>
    <html lang="es">
        <head>
            <meta charset="utf-8">
            <link rel="stylesheet" href="../CSS/sistema_erp.css">
            <title>Lista Insumos</title>
            
        </head>
        <header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Menú Inventario</a></li>
            <li><a class="menuitem active" href="../Interfaz_Menu/gestioninsumos.php">Volver</a></li>
            
        <ul>
    </nav>

</header>
<body>
<h3>Lista Insumos</h3>
<div>
    <div >
        <div id="filtro">
                <form id="metodopostfiltro" method="POST" class="formulario">
            <input  class="input-tabla" type="text" placeholder="Codigo" name="codigoinsumo"  >
            <input  class="input-tabla" type="text" placeholder="Nombre" name="nombreinsumo"  >
            <input  class="input-tabla" type="text" placeholder="Categoria" name="categoriainsumo"  >
            <input  class="input-tabla" type="text" placeholder="Proveedor" name="proveedor" >
            <input  class="input-tabla" type="text" placeholder="Almacen" name="almacen"  >
            <input  class="input-tabla" type="text" placeholder="Ubicacion" name="ubicacion"  >
            <button class="boton-lista" type="submit">Filtrar Insumo</button>
            </form>
        </div>
    </div>
</div>
<br>
<br>
<div >
    <table>
    <tr>
        <th>Codigo Insumo</th>
        <th>Nombre</th>
        <th>Categoria</th>
        <th>Stock</th>
        <th>Proveedor</th>
        <th>Almacen</th>
        <th>Ubicacion</th>
        <th>Precio Compra</th>
    </tr>
    <?php foreach ($tabla as $fila){ ?>
        <tr>
            <td><?php echo $fila['Codigo']; ?></td>
            <td><?php echo $fila['NombreInsumo']; ?></td>
            <td><?php echo $fila['Categoria']; ?></td>
            <td><?php echo $fila['Stock']; ?></td>
            <td><?php echo $fila['Proveedor']; ?></td>
            <td><?php echo $fila['Almacen']; ?></td>
            <td><?php echo $fila['Ubicacion']; ?></td>
            <td><?php echo $fila['PrecioCompra']; ?></td>
        </tr>
    <?php } ?>
    </table>
</div>

</body>
</html>