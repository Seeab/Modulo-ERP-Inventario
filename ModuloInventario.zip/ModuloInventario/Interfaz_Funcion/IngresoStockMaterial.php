<?php
require_once "../Clases/combobox.php";
require_once '../Clases/Material.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $codigoM=$_POST["cmbmaterial"];
    $stockM=$_POST["stock"];

    $material = new Material($codigoM,null,null,null,$stockM,null,null,null);
    $material->call_ingresar_stock();
}else{
    $combobox= new combobox();
    $cmbmaterial=$combobox->cmb_material();
    $combobox->cmb_CerrarConexion();
}
?>
<!DOCTYPE html>
<html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <title>Registro de Material</title>
</head>
<header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Menú Inventario</a></li>
            <li><a class="menuitem active" href="../Interfaz_Menu/gestionmateriales.php">Volver</a></li>
            
        <ul>
    </nav>
</header>
<body>
<div id="contenedor">
        <div id="centroregistro">
            <div class="login_registro">
                <form  method="post" class="formulario">
                  <h1>Registro de Material</h1> 
                  <select class="select" id="cmbOpciones" name="cmbmaterial" class="select">
                    <option selected disabled>Seleccione un material</option>
                <?php foreach ($cmbmaterial as $r) { ?>
                    <option  value="<?php echo $r['codigo_material']; ?>"><?php echo $r['nombre_material']; ?></option>
                <?php } ?>
                    </select>

                    <input class="input-form" type="number" placeholder="Ingresar Stock" name="stock" min="1" required><br>
                  <button type="submit" class="boton">Actualizar Stock</button>
                </form>
            </div>  
        </div>
    </div>
</body>
</html>
