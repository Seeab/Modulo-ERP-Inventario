<?php
require_once "../Clases/combobox.php";
require_once '../Clases/Insumo.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
$codigoI=$_POST["codigoinsumo"];
$nombreI=$_POST["nombreinsumo"];
$categoriaI=$_POST["cmbcategoriaInsumo"];
$proveedorI=$_POST["cmbproveedorInsumo"];
$almacenI=$_POST["cmbalmacenInsumo"];
$ubicacionI=$_POST["Ubicacion"];
$preciocompraI=$_POST["precio_compra"];

$insumo = new Insumo($codigoI, $nombreI,$categoriaI,$proveedorI,null, $almacenI, $ubicacionI,$preciocompraI);
$insumo->call_registrar_Insumo();
}else{
$combobox= new combobox();
$categoriainsumo=$combobox->cmb_categoria_insumo();
$proveedor=$combobox->cmb_Proveedor();
$almacen =$combobox->cmb_Almacen();
$combobox->cmb_CerrarConexion();
}
?>

<!DOCTYPE html>
<html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <title>Registro de Insumo</title>
</head>
<header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Menú Inventario</a></li>
            <li><a class="menuitem active" href="../Interfaz_Menu/gestioninsumos.php">Volver</a></li>
        <ul>
    </nav>
</header>
<body>
<div id="contenedor">
        <div id="centroregistro">
            <div class="login_registro">
                <form method="post" class="formulario">
                  <h2>Registro de Insumo</h2> 
                  <input class="input-form" type="number" placeholder="Codigo" name="codigoinsumo"  required min="1" required>
                  <input class="input-form" type="text" placeholder="Nombre" name="nombreinsumo" required>
                    <select class="select" name="cmbcategoriaInsumo" class="select">
                    <option selected disabled>Seleccione una categoria</option>
                <?php foreach ($categoriainsumo as $r) { ?>
                    <option  value="<?php echo $r['ID_categoria_insumo']; ?>"><?php echo $r['descripcion_insumo']; ?></option>
                <?php } ?>
                    </select>

                    <select class="select" name="cmbproveedorInsumo"class="select" >
                    <option selected disabled>Seleccione proveedor</option>
                <?php foreach ($proveedor as $r) { ?>
                    <option  value="<?php echo $r['ID_proveedor']; ?>"><?php echo $r['razonsocial']; ?></option>
                <?php } ?>
                    </select>

                    <select class="select" id="cmbOpciones" name="cmbalmacenInsumo" class="select">
                    <option selected disabled>Seleccione un almacen</option>
                <?php foreach ($almacen as $r) { ?>
                    <option  value="<?php echo $r['ID_almacen']; ?>"><?php echo $r['lugar']; ?></option>
                <?php } ?>
                    </select>
                  <textarea class="input-textarea" type="text" name="Ubicacion" placeholder="Ubicación:" rows="10" cols="39" required></textarea>
                  <input  class="input-form" type="number" placeholder="Precio de Compra" name="precio_compra" required min="1" step="any" required>
                  <button  type="submit" class="boton">Registrar</button>
                </form>
            </div>  
        </div>
    </div>
</body>
</html>