<?php
require_once '../Clases/Insumo.php';
    $insumo = new Insumo("null", "null", "null", "null",10, "null", "null", "null");
    $tabla = $insumo->call_tablaReabasteciminto_Insumo();

?>
<!DOCTYPE html>
<html>
    <html lang="es">
<head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../CSS/sistema_erp.css">
        <title>Lista Reabastecimiento Insumos</title>
</head>
<header>
        <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/ListasReabastecimiento.php">Volver</a></li>
        <ul>
    </nav>
</header>
<body>
<div >
<h2>Lista Reabastecimiento Insumos</h2> 
<label>Bajo de 10 de stock</label>
    <table>
    <tr>
        <th>Codigo Insumo</th>
        <th>Nombre</th>
        <th>Categoria</th>
        <th>Stock</th>
        <th>Proveedor</th>
        <th>Almacen</th>
        <th>Ubicacion</th>
    </tr>
    <?php foreach ($tabla as $fila){ ?>
        <tr>
            <td><?php echo $fila['CodigoInsumo']; ?></td>
            <td><?php echo $fila['Insumo']; ?></td>
            <td><?php echo $fila['Categoria']; ?></td>
            <td><?php echo $fila['Stock']; ?></td>
            <td><?php echo $fila['Proveedor']; ?></td>
            <td><?php echo $fila['Almacen']; ?></td>
            <td><?php echo $fila['Ubicacion']; ?></td>
        </tr>
    <?php } ?>
    </table>
</div>
</body>
</html>