<?php
require_once "../Clases/combobox.php";
require_once '../Clases/Material.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigoM=$_POST["codigomaterial"];
$nombreM=$_POST["nombrematerial"];
$categoriaM=$_POST["cmbcategoriaMaterial"];
$proveedorM=$_POST["cmbproveedorMaterial"];
$almacenM=$_POST["cmbalmacenMaterial"];
$ubicacionM=$_POST["Ubicacion"];
$preciocompraM=$_POST["precio_compra"];


$material = new Material($codigoM, $nombreM,$categoriaM,$proveedorM,null, $almacenM, $ubicacionM,$preciocompraM);
$material->call_registrar_Material();
}else{
$combobox= new combobox();
$categoriaMaterial=$combobox->cmb_categoria_material();
$proveedor=$combobox->cmb_Proveedor();
$almacen =$combobox->cmb_Almacen();
$combobox->cmb_CerrarConexion();
}
?>


<!DOCTYPE html>
<html>
    <html lang="es">
    <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <title>Registro de material</title>
    </head>
<header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Menú Inventario</a></li>
            <li><a class="menuitem active" href="../Interfaz_Menu/gestionmateriales.php">Volver</a></li>
        <ul>
    </nav>
</header>
<body>
<div id="contenedor">
        <div id="centroregistro">
            <div class="login_registro">
                <form  method="post" class="formulario">
                  <h1>Registro de material</h1> 
                  <input class="input-form" type="number" placeholder="Codigo" name="codigomaterial" required min="1" required>
                  <input class="input-form" type="text" placeholder="Nombre" name="nombrematerial" required>
                    <select  class="select" id="cmbOpciones" name="cmbcategoriaMaterial"  class="select">
                    <option selected disabled>Seleccione una categoria</option>
                <?php foreach ($categoriaMaterial as $r){ ?>
                    <option  value="<?php echo $r['ID_categoria_material']; ?>"><?php echo $r['descripcion_material']; ?></option>
                <?php } ?>
                    </select>

                    <select  class="select" id="cmbOpciones" name="cmbproveedorMaterial"  class="select">
                    <option selected disabled>Seleccione proveedor</option>
                <?php foreach ($proveedor as $r){ ?>
                    <option  value="<?php echo $r['ID_proveedor']; ?>"><?php echo $r['razonsocial']; ?></option>
                <?php } ?>
                    </select>

                    <select  class="select" id="cmbOpciones" name="cmbalmacenMaterial"  class="select">
                    <option selected disabled>Seleccione un almacen</option>
                <?php foreach ($almacen as $r){ ?>
                    <option  value="<?php echo $r['ID_almacen']; ?>"><?php echo $r['lugar']; ?></option>
                <?php } ?>
                    </select>
                  <textarea class="input-textarea" type="text" name="Ubicacion" placeholder="Ubicación:" required></textarea>
                  <input class="input-form" type="number" placeholder="Precio de Compra" name="precio_compra" required min="1" step="any" required>
                  <button  type="submit" class="boton">Registrar</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>