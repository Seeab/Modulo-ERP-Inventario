<?php
require_once '../Clases/Proveedor.php';

// Crear una instancia de la clase Proveedor
$proveedorObj = new Proveedor();

// Obtener la lista de proveedores y artículos asociados
$proveedores = $proveedorObj->obtenerArticulosPorProveedor();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <title>Lista Artículos por Proveedor</title>
    
</head>
<header>
    
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Menú Inventario</a></li>            
        <ul>
    </nav>
    <h3>Lista Artículos por Proveedor</h3>
</header>
<body>
<?php
if ($proveedores !== null) {
    foreach ($proveedores as $proveedor => $articulos) {
        ?>
        <div>
            <h3>Proveedor: <?php echo $proveedor; ?></h3>
            <table>
                <tr>
                    <th>Artículo</th>
                    <th>Tipo</th>
                    <th>Precio de Compra</th>
                </tr>
                <?php
                foreach ($articulos as $articulo) {
                    ?>
                    <tr>
                        <td><?php echo $articulo['nombre_articulo']; ?></td>
                        <td><?php echo $articulo['tipo']; ?></td>
                        <td><?php echo $articulo['precio_compra']; ?></td>
                    </tr>
                    <?php
                }
                ?>
            </table>
        </div>
        <?php
    }
} else {
    echo "No se encontraron resultados.";
}
?>
</body>
</html>