<?php
require_once "../Clases/combobox.php";
require_once '../Clases/Producto.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $codigoP=$_POST["codigoproducto"];
    $nombreP=$_POST["nombreproducto"];
    $categoriaP=$_POST["cmbcategoria_producto"];
    $proveedorP=$_POST["cmbproveedorProducto"];
    $almacenP=$_POST["cmbalmacenProducto"];
    $ubicacionP=$_POST["Ubicacion"];
    $precioventaP=$_POST["precio_venta"];
    $preciocompraP=$_POST["precio_compra"];
    
    
    $producto = new Producto($codigoP, $nombreP,$categoriaP,$proveedorP,null, $almacenP, $ubicacionP,$precioventaP,$preciocompraP);
    $producto->call_registrar_Producto();
}else{
    $combobox= new combobox();
    $categoriaProducto=$combobox->cmb_categoria_producto();
    $proveedor=$combobox->cmb_Proveedor();
    $almacen =$combobox->cmb_Almacen();
    $combobox->cmb_CerrarConexion();
}
?>

<!DOCTYPE html>
<html>
    <html lang="es">
    <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <title>Registro de Producto</title>
    </head>
<header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Menú Inventario</a></li>
            <li><a class="menuitem active" href="../Interfaz_Menu/gestionproductos.php">Volver</a></li>
        <ul>
    </nav>
</header>
<body>
<div id="contenedor">
        <div id="centroregistro">
            <div class="login_registro">
                <form  method="post" class="formulario">
                  <h1>Registro de Producto</h1> 
                  <input class="input-form" type="number" placeholder="Codigo" name="codigoproducto" required min="1" required>
                  <input class="input-form" type="text" placeholder="Nombre" name="nombreproducto" required>
                    <select class="select" id="cmbOpciones" name="cmbcategoria_producto" class="select">
                    <option selected disabled>Seleccione una categoria</option>
                <?php foreach ($categoriaProducto as $r) { ?>
                    <option  value="<?php echo $r['ID_categoria_producto']; ?>"><?php echo $r['descripcion_producto']; ?></option>
                <?php } ?>
                    </select>
                    <select class="select" id="cmbOpciones" name="cmbproveedorProducto" class="select" >
                    <option selected disabled>Seleccione proveedor</option>
                <?php foreach ($proveedor as $r) { ?>
                    <option  value="<?php echo $r['ID_proveedor']; ?>"><?php echo $r['razonsocial']; ?></option>
                <?php } ?>
                    </select>

                    <select class="select" id="cmbOpciones" name="cmbalmacenProducto"class="select" >
                    <option selected disabled>Seleccione un almacen</option>
                <?php foreach ($almacen as $r) { ?>
                    <option  value="<?php echo $r['ID_almacen']; ?>"><?php echo $r['lugar']; ?></option>
                <?php } ?>
                    </select>
                  <textarea class="input-textarea"  type="text" name="Ubicacion" placeholder="Ubicación:" required></textarea>
                  <input class="input-form" type="number" placeholder="Precio de Venta" name="precio_venta" required min="1" step="any" required>
                  <input class="input-form" type="number" placeholder="Precio de Compra" name="precio_compra" required min="1" step="any"required>
                  <button type="submit" class="boton">Registrar</button>
                </form>
            </div>  
        </div>
    </div>
</body>
</html>
