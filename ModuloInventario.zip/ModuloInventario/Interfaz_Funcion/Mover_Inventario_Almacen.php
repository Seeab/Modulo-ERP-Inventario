<?php
    require_once "../Clases/Almacen.php";
    require_once "../Clases/combobox.php";
    require_once "../Clases/producto.php";
    require_once '../Clases/material.php';
    require_once '../Clases/Insumo.php';


    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if(isset($_POST["idalmacenP"]) && isset($_POST["codigo_producto"]) &&  isset($_POST["UbicacionP"])){
            $id_almacen = $_POST["idalmacenP"];
            $codigo = $_POST["codigo_producto"];
            $ubicacion=$_POST["UbicacionP"];

            $cambio = new almacen($id_almacen, $codigo,$ubicacion);
            $cambio->call_cambio_almacen_producto();
        }
            
        if(isset($_POST["idalmacenM"]) && isset($_POST["codigo_material"]) &&  isset($_POST["UbicacionM"]) ){
        $id_almacen = $_POST["idalmacenM"];
            $codigo = $_POST["codigo_material"];
            $ubicacion=$_POST["UbicacionM"];

            $cambio = new almacen($id_almacen, $codigo,$ubicacion);
            $cambio->call_cambio_almacen_material();
        }

        if(isset($_POST["idalmacenI"]) && isset($_POST["codigo_insumo"]) &&  isset($_POST["UbicacionI"]) ){
            $id_almacen = $_POST["idalmacenI"];
            $codigo = $_POST["codigo_insumo"];
            $ubicacion=$_POST["UbicacionI"];

            $cambio = new almacen($id_almacen, $codigo,$ubicacion);
            $cambio->call_cambio_almacen_insumo();
        }
    }else{
        $producto = new Producto("null", "null", "null", "null",null, "null", "null", "null","null");
        $tabla1 = $producto->call_tabla_Producto_Almacen();
        
        $material = new Material("null", "null", "null", "null",null, "null", "null", "null");
        $tabla2 = $material->call_tabla_Material_Almacen();
       
        $insumo = new Insumo("null", "null", "null", "null",null, "null", "null", "null");
        $tabla3 = $insumo->call_tabla_Insumo_Almacen();

        $combobox= new combobox();
        $producto=$combobox->cmb_producto();
        $almacen=$combobox->cmb_Almacen();
        $material=$combobox->cmb_material();
        $insumo=$combobox->cmb_insumo();
        $combobox->cmb_CerrarConexion();
    }
    ?>

    
<!DOCTYPE html>
<html lang="es">
<head>
    <title>Cambio de almacen</title>
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <script>
    function enviarForm2() {
            var formulario = document.getElementById("Form2");
            var datosFormulario = new FormData(formulario);

            var xhr = new XMLHttpRequest();
            xhr.open("POST", "Mover_Inventario_Almacen.php", true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // La solicitud se completó con éxito
                    // Puedes realizar alguna acción adicional aquí si es necesario
                    location.reload();
                }
            };
            xhr.send(datosFormulario);
    }
    function enviarForm3() {
            var formulario = document.getElementById("Form3");
            var datosFormulario = new FormData(formulario);

            var xhr = new XMLHttpRequest();
            xhr.open("POST", "Mover_Inventario_Almacen.php", true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // La solicitud se completó con éxito
                    // Puedes realizar alguna acción adicional aquí si es necesario
                    location.reload();
                }
            };
            xhr.send(datosFormulario);
    }
    function enviarForm4() {
            var formulario = document.getElementById("Form4");
            var datosFormulario = new FormData(formulario);

            var xhr = new XMLHttpRequest();
            xhr.open("POST", "Mover_Inventario_Almacen.php", true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // La solicitud se completó con éxito
                    // Puedes realizar alguna acción adicional aquí si es necesario
                    location.reload();
                }
            };
            xhr.send(datosFormulario);
    }

     function mostrarFormulario() {
        var tipo = document.getElementById("tipo").value;
        var formulario1 = document.getElementById("Formulario1");
        var formulario2 = document.getElementById("Formulario2");
        var formulario3 = document.getElementById("Formulario3");
        var formulario4 = document.getElementById("Formulario4");

        formulario1.style.display = "none";
        formulario2.style.display = "none";
        formulario3.style.display = "none";
        formulario4.style.display = "none";

        if (tipo === "producto") {
            formulario2.style.display = "block";
        } else if (tipo === "material") {
            formulario3.style.display = "block";
        } else if (tipo === "insumo") {
            formulario4.style.display = "block";
        }
}

    </script>
</head>
<header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Volver al Menu Inventario</a></li>
        <ul>
    </nav>
</header>
<body>

<div id="Formulario1" >
    <div id="contenedor">
        <div id="centro">
            <div class="articulo">
                <h3>Gestión de almacenes</h3>
                <form id="Form1" method="POST">
                    <label for="tipo">Tipo de Cambio:</label><br>
                    <select class="select" id="tipo" name="tipo"  class="select1">
                        <option value="producto">Producto</option>
                        <option value="material">Material</option>
                        <option value="insumo">Insumo</option>
                    </select>
                    <br>
                    <button  class="boton" type="button" onclick="mostrarFormulario(); document.getElementById('Formulario1').style.display = 'none';">Elegir tipo de item</button>
                </form>
            </div>
        </div>
    </div>
</div>

    <div id="Formulario2" style="display: none;">
        <h3>Seleccionar Producto</h3>
        <form id="Form2" method="POST">
            <select class="select-tabla" id="cmbOpcionesP" name="idalmacenP" class="select">
                <option selected disabled>Seleccione un almacen</option>
                <?php foreach ($almacen as $r) { ?>
                    <option value="<?php echo $r['ID_almacen']; ?>"><?php echo $r['lugar']; ?></option>
                <?php } ?>
            </select>

            <select class="select-tabla" id="cmbOpcionesP" name="codigo_producto" class="select">
                <option selected disabled>Seleccione un producto</option>
                <?php foreach ($producto as $r) { ?>
                    <option value="<?php echo $r['codigo_producto']; ?>"><?php echo $r['nombre_producto']; ?></option>
                <?php } ?>
            </select>
            <input class="input-tabla" type="text" name="UbicacionP" placeholder="Ubicación:" required></input>
            <button class="boton-lista" type="button" onclick="enviarForm2()">Actualizar</button>
        </form>
        <table>
        <tr>
            <th>Codigo Producto</th>
            <th>Nombre</th>
            <th>Almacen</th>
            <th>Ubicacion</th>
        </tr>
        <?php foreach ($tabla1 as $fila){ ?>
            <tr>
                <td><?php echo $fila['Codigo']; ?></td>
                <td><?php echo $fila['Producto']; ?></td>
                <td><?php echo $fila['Almacen']; ?></td>
                <td><?php echo $fila['Ubicacion']; ?></td>
            </tr>
    <?php } ?>
    </table>
    </div>

    <div id="Formulario3" style="display: none;">
        <h3>Seleccionar Material</h3>
        <form id="Form3" method="POST">
            <select class="select-tabla" id="cmbOpcionesM" name="idalmacenM" class="select">
                <option selected disabled>Seleccione un almacen</option>
                <?php foreach ($almacen as $r) { ?>
                    <option value="<?php echo $r['ID_almacen']; ?>"><?php echo $r['lugar']; ?></option>
                <?php } ?>
            </select>

            <select class="select-tabla" id="cmbOpcionesM" name="codigo_material" class="select">
                <option selected disabled>Seleccione un material</option>
                <?php foreach ($material as $r) { ?>
                    <option value="<?php echo $r['codigo_material']; ?>"><?php echo $r['nombre_material']; ?></option>
                <?php } ?>
            </select>
            <input class="input-tabla" type="text" name="UbicacionM" placeholder="Ubicación:"  required></input>
            <button class="boton-lista" type="button" onclick="enviarForm3()">Actualizar</button>
        </form>
        <table>
        <tr>
            <th>Codigo Material</th>
            <th>Nombre</th>
            <th>Almacen</th>
            <th>Ubicacion</th>
        </tr>
        <?php foreach ($tabla2 as $fila){ ?>
            <tr>
                <td><?php echo $fila['Codigo']; ?></td>
                <td><?php echo $fila['Material']; ?></td>
                <td><?php echo $fila['Almacen']; ?></td>
                <td><?php echo $fila['Ubicacion']; ?></td>
            </tr>
    <?php } ?>
    </table>
    </div>

    <div id="Formulario4" style="display: none;">
        <h3>Seleccionar Insumo</h3>
        <form id="Form4" method="POST">
            <select class="select-tabla" id="cmbOpcionesI" name="idalmacenI" class="select">
                <option selected disabled>Seleccione un almacen</option>
                <?php foreach ($almacen as $r) { ?>
                    <option value="<?php echo $r['ID_almacen']; ?>"><?php echo $r['lugar']; ?></option>
                <?php } ?>
            </select>

            <select class="select-tabla" id="cmbOpcionesI" name="codigo_insumo" class="select">
                <option selected disabled>Seleccione un insumo</option>
                <?php foreach ($insumo as $r) { ?>
                    <option value="<?php echo $r['codigo_insumo']; ?>"><?php echo $r['nombre_insumo']; ?></option>
                <?php } ?>
            </select>
            <input class="input-tabla" type="text" name="UbicacionI" placeholder="Ubicación:"  required></input>
            <button class="boton-lista" type="button" onclick="enviarForm4()">Actualizar</button>
        </form>
        <table>
        <tr>
            <th>Codigo Insumo</th>
            <th>Nombre</th>
            <th>Almacen</th>
            <th>Ubicacion</th>
        </tr>
        <?php foreach ($tabla3 as $fila){ ?>
            <tr>
                <td><?php echo $fila['Codigo']; ?></td>
                <td><?php echo $fila['Insumo']; ?></td>
                <td><?php echo $fila['Almacen']; ?></td>
                <td><?php echo $fila['Ubicacion']; ?></td>
            </tr>
    <?php } ?>
    </table>
    </div>
</body>
</html>