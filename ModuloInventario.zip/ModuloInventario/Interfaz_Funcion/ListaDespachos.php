<?php
require_once '../Clases/conexion.php';
require_once '../Clases/Despacho.php';

$despacho = new Despacho();
$tabla = $despacho->call_tabla_despacho2();
?>
<!DOCTYPE html>
<html>
    <html lang="es">
        <head>
            <meta charset="utf-8">
            <link rel="stylesheet" href="../CSS/sistema_erp.css">
            
            <title>Lista Despachos</title>
         
        </head>
<header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Menú Inventario</a></li>
            <li><a class="menuitem active" href="../Interfaz_Menu/gestiondespachos.php">Volver</a></li>
            
        <ul>
    </nav>
</header>
<body>
<h3>Lista Despachos</h3> 
<div>
<table>
            <tr>
                <th>ID Orden de Venta</th>
                <th>Codigo Producto</th>
                <th>Cliente</th>
                <th>Direccion</th>
                <th>Estado</th>
                <th>Rut</th>
                <th>Total Orden</th>
            </tr>
            <?php foreach ($tabla as $fila) { ?>
                <tr>
                    <td><?php echo $fila['ID_Orden_Venta']; ?></td>
                    <td><?php echo $fila['Codigo']; ?></td>
                    <td><?php echo $fila['Nombre']; ?></td>
                    <td><?php echo $fila['Direccion']; ?></td>
                    <td><?php echo $fila['Estado']; ?></td>
                    <td><?php echo $fila['Rut']; ?></td>
                    <td><?php echo $fila['Total']; ?></td>
                </tr>
            <?php } ?>
        </table>
</div>

</body>
</html>