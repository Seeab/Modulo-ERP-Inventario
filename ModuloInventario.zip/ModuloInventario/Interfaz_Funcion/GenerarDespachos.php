<?php
require_once "../Clases/combobox.php";
require_once '../Clases/Despacho.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $despacho = new Despacho();
    $idOrden = $_POST["id_orden"];

    if (empty($idOrden)){
        header("Location: GenerarDespachos.php");
        exit;
    }else{
        $despacho->setDespacho($idOrden);
        $despacho->call_sp_despacho();
        header("Location: GenerarDespachos.php");
        exit;
    }
}else{

    $despacho = new Despacho();
    $tabla = $despacho->call_tabla_despacho();

    $combobox= new combobox();
    $cmbdespacho=$combobox->cmb_Despacho();
    $combobox->cmb_CerrarConexion();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <title>Gestión Despachos</title>
</head>
<header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Menú Inventario</a></li>
            <li><a class="menuitem active" href="../Interfaz_Menu/gestiondespachos.php">Volver</a></li>
        <ul>
    </nav>
    
</header>
<body>
    <h3>Lista despachos pendientes</h3>
    <div >
        <div id="filtro">
            <form method="POST" class="formulario">
            <select class="select-tabla" id="cmbOpciones" name="id_orden" class="select" >
                    <option selected disabled required>Seleccione una ID </option>
                    <?php foreach ($cmbdespacho as $r) { ?>
                        <option value="<?php echo $r['id_orden_venta']; ?>"><?php echo $r['id_orden_venta']; ?></option>
                    <?php } ?>
                </select>
                <button type="submit" class="boton-lista">Actualizar estado</button>
            </form>
        </div>
    </div>
    <br>
    <br>
    <div>
        <table>
            <tr>
                <th>ID Orden de Venta</th>
                <th>Codigo Producto</th>
                <th>Cliente</th>
                <th>Direccion</th>
                <th>Estado</th>
                <th>Rut</th>
                <th>Total Orden</th>
            </tr>
            <?php foreach ($tabla as $fila) { ?>
                <tr>
                    <td><?php echo $fila['ID_Orden_Venta']; ?></td>
                    <td><?php echo $fila['Codigo']; ?></td>
                    <td><?php echo $fila['Nombre']; ?></td>
                    <td><?php echo $fila['Direccion']; ?></td>
                    <td><?php echo $fila['Estado']; ?></td>
                    <td><?php echo $fila['Rut']; ?></td>
                    <td><?php echo $fila['Total']; ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>