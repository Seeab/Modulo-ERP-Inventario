<?php
require_once "../Clases/combobox.php";
require_once '../Clases/Producto.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $codigoP=$_POST["cmbproducto"];
    $stockP=$_POST["stock"];

    $producto = new Producto($codigoP,null,null,null,$stockP,null,null,null,null);
    $producto->call_ingresar_stock();
}else{
    $combobox= new combobox();
    $cmbproducto=$combobox->cmb_producto();
    $combobox->cmb_CerrarConexion();
}
?>
<!DOCTYPE html>
<html>
    <html lang="es">
    <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <title>Ingreso de stock producto</title>
    </head>
    <header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Menú Inventario</a></li>
            <li><a class="menuitem active" href="../Interfaz_Menu/gestionproductos.php">Volver</a></li>
            
        <ul>
    </nav>
</header>
<body>
<div id="contenedor">
        <div id="centro">
            <div class="login_registro">
                <form  method="post" class="formulario" >
                  <h3>Ingreso de stock producto</h3> 
                  <select class="select" id="cmbOpciones" name="cmbproducto" class="select">
                    <option selected disabled>Seleccione un producto</option>
                <?php foreach ($cmbproducto as $r) { ?>
                    <option  value="<?php echo $r['codigo_producto']; ?>"><?php echo $r['nombre_producto']; ?></option>
                <?php } ?>
                    </select>
                <input class="input-form" type="number" placeholder="Ingresar Stock" name="stock" min="1" required>
                <button type="submit" class="boton">Actualizar Stock</button>
                </form>
            </div>  
        </div>
    </div>
</body>
</html>
