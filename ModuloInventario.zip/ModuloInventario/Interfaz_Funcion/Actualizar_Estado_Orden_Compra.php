<?php
require_once "../Clases/combobox.php";
require_once '../Clases/Orden_Compra.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
        $orden_compra = new Orden_Compra();
        $codigo = $_POST["ID_OC"];
        if(empty($codigo)){
            header("Location: ../Interfaz_Funcion/Actualizar_Estado_Orden_Compra.php");
            exit;
        }else{
            $orden_compra->setCodigo($codigo);
    
            $orden_compra->call_recepcion_OC();
    
            $tabla = $orden_compra->call_tabla_OC_pendiente();

            header("Location: ../Interfaz_Funcion/Actualizar_Estado_Orden_Compra.php");
            exit;
        }
    }else{

        $combobox= new combobox();
        $OC=$combobox->cmb_OrdenCompra();

        $orden_compra = new Orden_Compra();
        $tabla = $orden_compra->call_tabla_OC_pendiente();
}

?>
<!DOCTYPE html>
<html>
    <html lang="es">
        <head>
            <meta charset="utf-8">
            <link rel="stylesheet" href="../CSS/sistema_erp.css">
            <title>Actualizar Estado Orden Compra</title>
            
        </head>
    <header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Volver al Menu Inventario</a></li> 
        <ul>
    </nav>
    <h3>Actualizar Estado Orden Compra</h3> 
</header>
<body>
    <div>

            <div id="filtro">
                <form id="" method="POST" class="formulario">
                <select class="select-tabla" id="cmbOpciones" name="ID_OC" class="select">
                    <option selected disabled required>Seleccione una ID </option>
                <?php foreach ($OC as $r) { ?>
                    <option  value="<?php echo $r['ID_OC']; ?>"><?php echo $r['ID_OC']; ?></option>
                <?php } ?>
                </select>
                  <button type="submit" class="boton-lista">Aceptar</button>
                </form>
            </div>
    </div>
<br>
<br>
<div >
    <table>
    <tr>
        <th>ID Orden</th>
        <th>Fecha</th>
        <th>Total</th>
        <th>EstadoOrden</th>
    </tr>
    <?php foreach ($tabla as $fila){ ?>
        <tr>
            <td><?php echo $fila['ID_Orden']; ?></td>
            <td><?php echo $fila['Fecha']; ?></td>
            <td><?php echo $fila['Total']; ?></td>
            <td><?php echo $fila['EstadoOrden']; ?></td>
        </tr>
    <?php } ?>
    </table>
</div>
</body>
</html>