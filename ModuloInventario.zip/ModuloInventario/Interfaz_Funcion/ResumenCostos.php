<?php
require_once '../Clases/conexion.php';
require_once '../Clases/Orden_Compra.php';

$orden_compra = new Orden_Compra();
$fechas = $orden_compra->obtenerFechasMinMax();

$fechaMinima = $fechas[0];
$fechaMaxima = $fechas[1];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
        $fechaInicio= $_POST["fecha_inicio"];
        $fechaTermino= $_POST["fecha_fin"];

        $tabla1 = [];
        $tabla2 = [];

        if(empty($fechaInicio) || empty($fechaTermino)){

        }else{
            $orden_compra->setFechaInicio($fechaInicio);
            $orden_compra->setFechaTermino($fechaTermino);
            $tabla1 = $orden_compra->call_VerTotalCostos();
            $tabla2 = $orden_compra->call_VerResumenCostos();
        }
    }else{
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <title>Resumen de costos</title>
</head>
<header>
    
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Volver al Menu Inventario</a></li> 
        <ul>
    </nav>
</header>
<body>
    <h3>Resumen de costos</h3>
    <div>
  <div >
    <div id="filtro">
      <form id="formulario" method="POST" class="formulario">
        <label for="fecha_inicio">Fecha de inicio:</label>
        <input class="input-tabla" type="date" name="fecha_inicio" id="fecha_inicio" value="<?php echo date('Y-m-d'); ?>" required min="<?php echo $fechaMinima; ?>" max="<?php echo $fechaMaxima; ?>">

        <label for="fecha_fin">Fecha de fin:</label>
        <input class="input-tabla" type="date" name="fecha_fin" id="fecha_fin" value="<?php echo date('Y-m-d'); ?>" required min="<?php echo $fechaMinima; ?>" max="<?php echo $fechaMaxima; ?>">
        <button type="submit" class="boton-lista">Aceptar</button>
      </form>
    </div>
  </div>
</div>
<br>

    <?php if (!empty($tabla1)): ?>
        <table>
            <tr>
                <th>Total</th>
            </tr>
            <?php foreach ($tabla1 as $fila): ?>
                <tr>
                    <td><?php echo $fila['Total']; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <br>
    <?php endif; ?>

    <?php if (!empty($tabla2)): ?>
        <div>
            <table>
                <tr>
                    <th>ID Orden</th>
                    <th>Fecha</th>
                    <th>Total</th>
                    <th>EstadoOrden</th>
                </tr>
                <?php foreach ($tabla2 as $fila): ?>
                    <tr>
                        <td><?php echo $fila['ID_Orden']; ?></td>
                        <td><?php echo $fila['Fecha']; ?></td>
                        <td><?php echo $fila['Total']; ?></td>
                        <td><?php echo $fila['EstadoOrden']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    <?php endif; ?>
</body>
</html>