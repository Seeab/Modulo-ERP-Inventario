<?php
require_once '../Clases/Producto.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigoP = $_POST["codigoproducto"] !== "" ? $_POST["codigoproducto"] : "null";
    $nombreP = $_POST["nombreproducto"] !== "" ? $_POST["nombreproducto"] : "null";
    $categoriaP = $_POST["categoriaproducto"] !== "" ? $_POST["categoriaproducto"] : "null";
    $proveedorP = $_POST["proveedor"] !== "" ? $_POST["proveedor"] : "null";
    $almacenP = $_POST["almacen"] !== "" ? $_POST["almacen"] : "null";
    $ubicacionP = $_POST["ubicacion"] !== "" ? $_POST["ubicacion"] : "null";

    $producto = new Producto($codigoP, $nombreP, $categoriaP, $proveedorP,null, $almacenP, $ubicacionP, null,null);

    if ($codigoP === "null" && $nombreP === "null" && $categoriaP === "null" && $proveedorP === "null" && $almacenP === "null" && $ubicacionP === "null") {
        $tabla = $producto->call_tabla_Producto();
    } else {
        $tabla = $producto->call_filtro_Producto();
    }
} else {
    $producto = new Producto("null", "null", "null", "null",null, "null", "null", "null","null");
    $tabla = $producto->call_tabla_Producto();
}
?>

<!DOCTYPE html>
<html>
    <html lang="es">
        <head>
            <meta charset="utf-8">
            <link rel="stylesheet" href="../CSS/sistema_erp.css">
            <title>Lista Productos</title>
        </head>
        <header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="../Interfaz_Menu/menuinventario.php">Menú Inventario</a></li>
            <li><a class="menuitem active" href="../Interfaz_Menu/gestionproductos.php">Volver</a></li>
            
        <ul>
       
    </nav>
    <h3>Lista Productos</h3> 
</header>
<body>
<div>
        <div >
            <div id="filtro">
                <form id="metodopostfiltro" method="POST" class="formulario">
                  
                  <input class="input-tabla" type="text" placeholder="Codigo" name="codigoproducto"  >
                  <input class="input-tabla" type="text" placeholder="Nombre" name="nombreproducto"  >
                  <input class="input-tabla" type="text" placeholder="Categoria" name="categoriaproducto"  >
                  <input class="input-tabla" type="text" placeholder="Proveedor" name="proveedor" >
                  <input class="input-tabla" type="text" placeholder="Almacen" name="almacen"  >
                  <input class="input-tabla" type="text" placeholder="Ubicacion" name="ubicacion"  >
                  <button class="boton-lista" type="submit">Filtrar Producto</button>
                </form>
            </div>
        </div>
</div>
<br>
<br>
<div >
    <table>
    <tr>
        <th>Codigo Producto</th>
        <th>Nombre</th>
        <th>Categoria</th>
        <th>Stock</th>
        <th>Proveedor</th>
        <th>Almacen</th>
        <th>Ubicacion</th>
        <th>Precio Compra</th>
    </tr>
    <?php foreach ($tabla as $fila){ ?>
        <tr>
            <td><?php echo $fila['CodigoProducto']; ?></td>
            <td><?php echo $fila['Producto']; ?></td>
            <td><?php echo $fila['Categoria']; ?></td>
            <td><?php echo $fila['Stock']; ?></td>
            <td><?php echo $fila['Proveedor']; ?></td>
            <td><?php echo $fila['Almacen']; ?></td>
            <td><?php echo $fila['Ubicacion']; ?></td>
            <td><?php echo $fila['PrecioCompra']; ?></td>
        </tr>
    <?php } ?>
    </table>
</div>

</body>
</html>