create database sistema_erp collate utf8mb4_spanish2_ci charset utf8mb4;

use sistema_erp;

-- tablas inventario
create table proveedores(
ID_proveedor int primary key,
razonsocial  varchar(255),
telefono varchar(12),
correo varchar(255)
);

create table almacen(
ID_almacen int primary key,
lugar varchar(255)
);

create table tipo_orden_compra(
ID_tipo_OC int primary key,
descripcion_tipo_OC varchar(255)
);

--
create table orden_compra(
ID_OC int primary key auto_increment,
fecha_OC date,
estado_OC varchar(20),
tipo_OC int,
precio_total_OC float,
FOREIGN KEY(tipo_OC) references tipo_orden_compra(ID_tipo_OC)
);
--
create table categoria_producto(
ID_categoria_producto int primary key,
descripcion_producto varchar(255)
);

create table categoria_material(
ID_categoria_material int primary key,
descripcion_material varchar(255)
);

create table categoria_insumo(
ID_categoria_insumo int primary key,
descripcion_insumo varchar(255)
);
--                                                 -- 
create table producto(
codigo_producto int primary key,
nombre_producto varchar(255),
ID_categoria_producto int,
stock_producto int,
ID_proveedor_producto int,
ID_almacen_producto int,
ubicacion_producto varchar(255),
precio_venta_producto float,
precio_compra_producto float,
FOREIGN KEY(ID_categoria_producto) references categoria_producto(ID_categoria_producto),
FOREIGN KEY(ID_proveedor_producto) references proveedores(ID_proveedor),
FOREIGN KEY(ID_almacen_producto) references almacen(ID_almacen)
);

create table material(
codigo_material int primary key,
nombre_material varchar(255),
ID_categoria_material int,
stock_material int,
ID_proveedor_material int,
ID_almacen_material int,
ubicacion_material varchar(255),
precio_compra_material float,
FOREIGN KEY(ID_categoria_material) references categoria_material(ID_categoria_material),
FOREIGN KEY(ID_proveedor_material) references proveedores(ID_proveedor),
FOREIGN KEY(ID_almacen_material) references almacen(ID_almacen)
);

create table insumo(
codigo_insumo int primary key,
nombre_insumo varchar(255),
ID_categoria_insumo int,
stock_insumo int,
ID_proveedor_insumo int,
ID_almacen_insumo int,
ubicacion_insumo varchar(255),
precio_compra_insumo float,
FOREIGN KEY(ID_categoria_insumo) references categoria_insumo(ID_categoria_insumo),
FOREIGN KEY(ID_proveedor_insumo) references proveedores(ID_proveedor),
FOREIGN KEY(ID_almacen_insumo) references almacen(ID_almacen)
);


create table detalles_orden_compra_productos(
ID_orden_DOCP int,
codigo_DOCP int,
cantidad_DOCP int,
ID_proveedor_DOCP int,
FOREIGN KEY(ID_orden_DOCP) references orden_compra(ID_OC),
FOREIGN KEY(codigo_DOCP) references producto(codigo_producto),
FOREIGN KEY(ID_proveedor_DOCP) references proveedores(ID_proveedor)
);

create table detalles_orden_compra_materiales(
ID_orden_DOCM int,
codigo_DOCM int,
cantidad_DOCM int,
ID_proveedor_DOCM int,
FOREIGN KEY(ID_orden_DOCM) references orden_compra(ID_OC),
FOREIGN KEY(codigo_DOCM) references material(codigo_material),
FOREIGN KEY(ID_proveedor_DOCM) references proveedores(ID_proveedor)
);

create table detalles_orden_compra_insumos(
ID_orden_DOCI int,
codigo_DOCI int,
cantidad_DOCI int,
ID_proveedor_DOCI int,
FOREIGN KEY(ID_orden_DOCI) references orden_compra(ID_OC),
FOREIGN KEY(codigo_DOCI) references insumo(codigo_insumo),
FOREIGN KEY(ID_proveedor_DOCI) references proveedores(ID_proveedor)
);

-- Tablas produccion
create table lote(
cod_lote int primary key auto_increment,
codigo_producto int,
cantidad int,
foreign key (codigo_producto) references producto(codigo_producto)
);

create table lote_material(
cod_lote int ,
codigo_material int,
cantidad int,
FOREIGN KEY	(codigo_material) references material(codigo_material),
FOREIGN KEY	(cod_lote) references lote(cod_lote)
);

create table estado_orden (
id_estado int primary key auto_increment,
descripcion varchar (20)
);
create table orden_produccion (
id_orden_produccion int primary key auto_increment,
fecha_ingreso date,
id_estado int,
fecha_salida date,
foreign key (id_estado) references estado_orden(id_estado)
);
create table detalle_orden_produccion (
id_orden_produccion int,
codigo_producto int,
cantidad int,
foreign key (id_orden_produccion) references orden_produccion(id_orden_produccion),
foreign key (codigo_producto) references producto(codigo_producto)
);

create table detalle_produccion(
id_orden_produccion int,
cod_lote int ,
foreign key (id_orden_produccion) references orden_produccion(id_orden_produccion),
FOREIGN KEY	(cod_lote) references lote(cod_lote)
);

create table maquina(
id_maquina int primary key auto_increment,
nombre varchar (255),
descripcion varchar (255),
fecha_mantenimiento date
);

create table tipo_mantenimiento(
id_tipo_mante int primary key auto_increment,
descripcion varchar(40)
);

create table orden_mante_maquina(
id_mante_maquina int primary key auto_increment,
id_maquina int,
id_estado int,
id_tipo_mante int,
fecha_ingreso date,
descripcion_proble varchar(255),
descripcion_mante varchar(255),
fecha_salida date,
foreign key (id_maquina) references maquina(id_maquina),
foreign key (id_estado) references estado_orden(id_estado),
foreign key (id_tipo_mante) references tipo_mantenimiento(id_tipo_mante) 
);

create table mante_maquina_encargado(
id_mante_maquina int,
id_empleado int,
foreign key (id_mante_maquina) references orden_mante_maquina(id_mante_maquina),
foreign key (id_empleado) references empleados(id_empleado)
);

create table mantenimiento_material(
id_mante_maquina int,
codigo_material int,
cantida int,
foreign key (id_mante_maquina) references orden_mante_maquina(id_mante_maquina),
FOREIGN KEY	(codigo_material) references material(codigo_material)
);

-- Tablas RRHH
