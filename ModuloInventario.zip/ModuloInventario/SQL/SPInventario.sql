use sistema_erp_inventario;

-- SP Relleno de cmbs
delimiter $$
create procedure sp_cmbProveedor(
)
Begin
select ID_proveedor,razonsocial from proveedores;
End
$$

call sp_cmbProveedor();

delimiter $$
create procedure sp_cmbAlmacen(
)
Begin
select ID_almacen,lugar from almacen;
End
$$

call sp_cmbAlmacen();

delimiter $$
create procedure sp_cmbcategoria_producto(
)
Begin
SELECT ID_categoria_producto,descripcion_producto FROM categoria_producto;
End
$$

call sp_cmbcategoria_producto();

delimiter $$
create procedure sp_cmbcategoria_material(
)
Begin
select ID_categoria_material,descripcion_material from categoria_material;
End
$$

call sp_cmbcategoria_material();

delimiter $$
create procedure sp_cmbcategoria_insumo(
)
Begin
select ID_categoria_insumo,descripcion_insumo from categoria_insumo;
End
$$

call sp_cmbcategoria_insumo();


delimiter $$
create procedure sp_cmbproducto(
)
Begin
select codigo_producto,nombre_producto from producto ;
End
$$

call sp_cmbproducto();

delimiter $$
create procedure sp_cmbmaterial(
)
Begin
select codigo_material,nombre_material from material ;
End
$$

call sp_cmbmaterial();

delimiter $$
create procedure sp_cmbinsumo(
)
Begin
select codigo_insumo,nombre_insumo from insumo ;
End
$$

call sp_cmbinsumo();


-- Sp relleno cmb orden compra
delimiter $$
create procedure sp_cmbOrdencompra()
begin
select ID_OC, ID_OC from orden_compra where estado_OC='pendiente';
end
$$

call sp_cmbOrdencompra();

delimiter $$
create procedure sp_cmbdespacho(
)begin
select id_orden_venta, id_orden_venta
from orden_de_venta
where estado = "Pendiente";
end $$

call sp_cmbdespacho();

-- 	SP registrar en lista Producto
delimiter $$
create procedure sp_registrar_Producto(
IN _codigo_producto int ,
IN _nombre_producto varchar(255) ,
IN _ID_categoria_producto int ,
IN _stock_producto int ,
IN _ID_proveedor_producto int ,
IN _ID_almacen_producto int ,
IN _ubicacion_producto varchar(255) ,
IN _precio_venta_producto float ,
IN _precio_compra_producto float
)begin
INSERT INTO producto
(`codigo_producto`,`nombre_producto`,`ID_categoria_producto`,`stock_producto`,`ID_proveedor_producto`,`ID_almacen_producto`,`ubicacion_producto`,`precio_venta_producto`,`precio_compra_producto`)
VALUES
(_codigo_producto,_nombre_producto,_ID_categoria_producto,_stock_producto,_ID_proveedor_producto,_ID_almacen_producto,_ubicacion_producto,_precio_venta_producto,_precio_compra_producto);
end
$$

call sp_registrar_Producto(1,"producto 1",1,25,1,1,"Pasillo(rack 12)",233,255);

select * from producto;

-- SP registrar en lista material
delimiter $$
create procedure sp_registro_material(
IN _codigo_material int,
IN _nombre_material varchar(255) ,
IN _ID_categoria_material int ,
IN _stock_material int ,
IN _ID_proveedor_material int ,
IN _ID_almacen_material int ,
IN _ubicacion_material varchar(255) ,
IN _precio_compra_material float
)
Begin
INSERT INTO material
(codigo_material,nombre_material,ID_categoria_material,stock_material,ID_proveedor_material,ID_almacen_material,ubicacion_material,precio_compra_material)
VALUES
(_codigo_material,_nombre_material,_ID_categoria_material,_stock_material,_ID_proveedor_material,_ID_almacen_material,_ubicacion_material,_precio_compra_material);
End
$$

call sp_registro_material(1,"prueba1",1,25,1,1,"rack 1",1);

select * from material;

delimiter $$
create procedure sp_registrar_Insumo(
IN _codigo_insumo int, 
IN _nombre_insumo varchar(255) ,
IN _ID_categoria_insumo int ,
IN _stock_insumo int ,
IN _ID_proveedor_insumo int ,
IN _ID_almacen_insumo int ,
IN _ubicacion_insumo varchar(255) ,
IN _precio_compra_insumo float
)begin
INSERT INTO insumo
(`codigo_insumo`,`nombre_insumo`,`ID_categoria_insumo`,`stock_insumo`,`ID_proveedor_insumo`,`ID_almacen_insumo`,`ubicacion_insumo`,`precio_compra_insumo`)
VALUES
(_codigo_insumo ,_nombre_insumo,_ID_categoria_insumo,_stock_insumo,_ID_proveedor_insumo,_ID_almacen_insumo,_ubicacion_insumo,_precio_compra_insumo);
end
$$

CALL sp_registrar_Insumo(1,"prueba",1,25,1,1,"rack1",123);

select * from insumo;


-- 			SP Lista producto
delimiter $$
create procedure sp_verlistaproductos()
begin
select p.codigo_producto as CodigoProducto,
p.nombre_producto as Producto,
cp.descripcion_producto as Categoria,
p.stock_producto as Stock,
pro.razonsocial as Proveedor,
a.lugar as Almacen,
ubicacion_producto as Ubicacion,
precio_venta_producto as PrecioVenta,
precio_compra_producto as PrecioCompra
from producto p
left join categoria_producto cp
on cp.ID_categoria_producto = p.ID_categoria_producto
left join proveedores pro
on p.ID_proveedor_producto = ID_proveedor
left join almacen a
on p.ID_almacen_producto = ID_almacen;
end
$$

call sp_verlistaproductos()


-- filtro productos
DELIMITER $$
CREATE PROCEDURE sp_filtrolistaproductos(
    IN _codigo_producto INT,
    IN _nombre_producto VARCHAR(255),
    IN _descripcion_producto VARCHAR(255),
    IN _razonsocial VARCHAR(255),
    IN _lugar VARCHAR(255),
    IN _ubicacion_producto VARCHAR(255)
)
BEGIN
    SET @codigo_producto = CONCAT('%', _codigo_producto, '%');
    SET @nombre_producto = CONCAT('%', _nombre_producto, '%');
    SET @descripcion_producto = CONCAT('%', _descripcion_producto, '%');
    SET @razonsocial = CONCAT('%', _razonsocial, '%');
    SET @lugar = CONCAT('%', _lugar, '%');
    SET @ubicacion_producto = CONCAT('%', _ubicacion_producto, '%');

    SELECT
        p.codigo_producto AS CodigoProducto,
        p.nombre_producto AS Producto,
        cp.descripcion_producto AS Categoria,
        p.stock_producto AS Stock,
        pro.razonsocial AS Proveedor,
        a.lugar AS Almacen,
        p.ubicacion_producto AS Ubicacion,
        p.precio_compra_producto AS PrecioCompra
    FROM producto p
    LEFT JOIN categoria_producto cp ON cp.ID_categoria_producto = p.ID_categoria_producto
    LEFT JOIN proveedores pro ON p.ID_proveedor_producto = pro.ID_proveedor
    LEFT JOIN almacen a ON p.ID_almacen_producto = a.ID_almacen
    WHERE p.codigo_producto LIKE @codigo_producto
        OR p.nombre_producto LIKE @nombre_producto
        OR cp.descripcion_producto LIKE @descripcion_producto
        OR pro.razonsocial LIKE @razonsocial
        OR a.lugar LIKE @lugar
        OR p.ubicacion_producto LIKE @ubicacion_producto;
END
$$

CALL sp_filtrolistaproductos(null,null,null,null,'almacen',null);
-- procedimiento de lista materiales
delimiter $$
create procedure sp_verlistamateriales()
begin
select m.codigo_material as Codigo,
m.nombre_material as NombreMaterial,
cm.descripcion_material as Categoria,
m.stock_material as Stock,
pro.razonsocial as Proveedor,
a.lugar as Almacen,
m.ubicacion_material as Ubicacion,
m.precio_compra_material as PrecioCompra
from material m
left join categoria_material cm
on cm.ID_categoria_material = m.ID_categoria_material
left join proveedores pro
on m.ID_proveedor_material = ID_proveedor
left join almacen a
on m.ID_almacen_material = ID_almacen;
end
$$

call sp_verlistamateriales();

-- procedimiento de lista materiales
DELIMITER $$
CREATE PROCEDURE sp_filtrolistamateriales(
    IN _codigo INT,
    IN _nombre VARCHAR(255),
    IN _descripcion VARCHAR(255),
    IN _razonsocial VARCHAR(255),
    IN _lugar VARCHAR(255),
    IN _ubicacion VARCHAR(255)
)
BEGIN
    SET @codigo = CONCAT('%', _codigo, '%');
    SET @nombre = CONCAT('%', _nombre, '%');
    SET @descripcion = CONCAT('%', _descripcion, '%');
    SET @razonsocial = CONCAT('%', _razonsocial, '%');
    SET @lugar = CONCAT('%', _lugar, '%');
    SET @ubicacion = CONCAT('%', _ubicacion, '%');

    SELECT
        m.codigo_material AS Codigo,
        m.nombre_material AS NombreMaterial,
        cm.descripcion_material AS Categoria,
        m.stock_material AS Stock,
        pro.razonsocial AS Proveedor,
        a.lugar AS Almacen,
        m.ubicacion_material AS Ubicacion,
        m.precio_compra_material AS PrecioCompra
    FROM material m
    LEFT JOIN categoria_material cm ON cm.ID_categoria_material = m.ID_categoria_material
    LEFT JOIN proveedores pro ON m.ID_proveedor_material = pro.ID_proveedor
    LEFT JOIN almacen a ON m.ID_almacen_material = a.ID_almacen
    WHERE m.codigo_material LIKE @codigo
        OR m.nombre_material LIKE @nombre
        OR cm.descripcion_material LIKE @descripcion
        OR pro.razonsocial LIKE @razonsocial
        OR a.lugar LIKE @lugar
        OR m.ubicacion_material LIKE @ubicacion;
END
$$

CALL sp_filtrolistamateriales(2,null,null,null,null,null);

-- SP lista sin filtrar
delimiter $$
create procedure sp_verlistainsumos(
)
begin
select
i.codigo_insumo as Codigo,
i.nombre_insumo as NombreInsumo,
ci.descripcion_insumo as Categoria,
i.stock_insumo as Stock,
pro.razonsocial as Proveedor,
a.lugar as Almacen,
i.ubicacion_insumo as Ubicacion,
i.precio_compra_insumo as PrecioCompra
from insumo i
left join categoria_insumo ci
on ci.ID_categoria_insumo = i.ID_categoria_insumo
left join proveedores pro
on i.ID_proveedor_insumo = pro.ID_proveedor
left join almacen a
on i.ID_almacen_insumo = ID_almacen;
end
$$

call sp_verlistainsumos();

-- SP lista filtrada 
DELIMITER $$
CREATE PROCEDURE sp_filtrolistainsumos(
    IN _codigo_insumo INT,
    IN _nombre_insumo VARCHAR(255),
    IN _descripcion_insumo VARCHAR(255),
    IN _razonsocial VARCHAR(255),
    IN _lugar VARCHAR(255),
    IN _ubicacion_insumo VARCHAR(255)
)
BEGIN
    SET @codigo_insumo = CONCAT('%', _codigo_insumo, '%');
    SET @nombre_insumo = CONCAT('%', _nombre_insumo, '%');
    SET @descripcion_insumo = CONCAT('%', _descripcion_insumo, '%');
    SET @razonsocial = CONCAT('%', _razonsocial, '%');
    SET @lugar = CONCAT('%', _lugar, '%');
    SET @ubicacion_insumo = CONCAT('%', _ubicacion_insumo, '%');

    SELECT
        i.codigo_insumo AS Codigo,
        i.nombre_insumo AS NombreInsumo,
        ci.descripcion_insumo AS Categoria,
        i.stock_insumo AS Stock,
        pro.razonsocial AS Proveedor,
        a.lugar AS Almacen,
        i.ubicacion_insumo AS Ubicacion,
        i.precio_compra_insumo AS PrecioCompra
    FROM insumo i
    LEFT JOIN categoria_insumo ci ON ci.ID_categoria_insumo = i.ID_categoria_insumo
    LEFT JOIN proveedores pro ON i.ID_proveedor_insumo = pro.ID_proveedor
    LEFT JOIN almacen a ON i.ID_almacen_insumo = a.ID_almacen
    WHERE i.codigo_insumo LIKE @codigo_insumo
        OR i.nombre_insumo LIKE @nombre_insumo
        OR ci.descripcion_insumo LIKE @descripcion_insumo
        OR pro.razonsocial LIKE @razonsocial
        OR a.lugar LIKE @lugar
        OR i.ubicacion_insumo LIKE @ubicacion_insumo;
END
$$

CALL sp_filtrolistainsumos(null,null,null,null,'almacen 2',null);

-- SP agregar stock producto
delimiter $$
create procedure sp_ingresarstockproducto(
    IN _codigo int,
    IN _stock int
)
Begin
    DECLARE stock_actual int;

    SELECT stock_producto INTO stock_actual FROM producto WHERE codigo_producto = _codigo;

	SET stock_actual = stock_actual + _stock;
	UPDATE producto SET stock_producto = stock_actual WHERE codigo_producto = _codigo;
End
$$

call sp_ingresarstockproducto(1,30);



delimiter $$
create procedure sp_ingresarstockmaterial(
    IN _codigo int,
    IN _stock int
)
Begin
    DECLARE stock_actual int;

    SELECT stock_material INTO stock_actual FROM material WHERE codigo_material = _codigo;

    SET stock_actual = stock_actual + _stock;
    UPDATE material SET stock_material = stock_actual WHERE codigo_material = _codigo;
End
$$

call sp_ingresarstockmaterial(1,30);

select * from material;

delimiter $$
create procedure sp_ingresarstockinsumo(
    IN _codigo int,
    IN _stock int
)
Begin
    DECLARE stock_actual int;

    SELECT stock_insumo INTO stock_actual FROM insumo WHERE codigo_insumo = _codigo;

    SET stock_actual = stock_actual + _stock;
    UPDATE insumo SET stock_insumo = stock_actual WHERE codigo_insumo = _codigo;
End$$

call sp_ingresarstockinsumo(1,30);

-- SP lista reabastecimiento productos
delimiter $$
create procedure sp_verlistareabastecimientoproductos()
begin
select p.codigo_producto as CodigoProducto,
p.nombre_producto as Producto,
cp.descripcion_producto as Categoria,
p.stock_producto as Stock,
pro.razonsocial as Proveedor,
a.lugar as Almacen,
ubicacion_producto as Ubicacion
from producto p
left join categoria_producto cp
on cp.ID_categoria_producto = p.ID_categoria_producto
left join proveedores pro
on p.ID_proveedor_producto = ID_proveedor
left join almacen a
on p.ID_almacen_producto = ID_almacen
where p.stock_producto<=10;
end
$$

call sp_verlistareabastecimientoproductos();

-- SP lista reabastecimiento materiales
delimiter $$
create procedure sp_verlistareabastecimientomateriales()
begin
select m.codigo_material as CodigoMaterial,
m.nombre_material as Material,
cm.descripcion_material as Categoria,
m.stock_material as Stock,
pro.razonsocial as Proveedor,
a.lugar as Almacen,
ubicacion_material as Ubicacion
from material m
left join categoria_material cm
on  cm.ID_categoria_material = m.ID_categoria_material
left join proveedores pro
on m.ID_proveedor_material = ID_proveedor
left join almacen a
on m.ID_almacen_material = ID_almacen
where m.stock_material<=10;
end
$$

call sp_verlistareabastecimientomateriales();

-- SP lista reabastecimiento insumos
delimiter $$
create procedure sp_verlistareabastecimientoinsumos()
begin
select 
i.codigo_insumo as CodigoInsumo,
i.nombre_insumo as Insumo,
ci.descripcion_insumo as Categoria,
i.stock_insumo as Stock,
pro.razonsocial as Proveedor,
a.lugar as Almacen,
ubicacion_insumo as Ubicacion
from insumo i
left join categoria_insumo ci
on  ci.ID_categoria_insumo = i.ID_categoria_insumo
left join proveedores pro
on i.ID_proveedor_insumo = pro.ID_proveedor
left join almacen a
on i.ID_almacen_insumo = a.ID_almacen
where i.stock_insumo<=10;
end
$$

call sp_verlistareabastecimientoinsumos();

-- SP crear orden de compra tipo 1
delimiter $$
create procedure sp_crear_orden_compra_producto()
begin
INSERT INTO orden_compra(fecha_OC,estado_OC,tipo_OC,precio_total_OC)
VALUES (date(now()),"Pendiente",1,0);
end
$$

call sp_crear_orden_compra_producto();

-- SP crear orden de compra tipo 2
delimiter $$
create procedure sp_crear_orden_compra_material()
begin
INSERT INTO orden_compra(fecha_OC,estado_OC,tipo_OC,precio_total_OC)
VALUES (date(now()),"Pendiente",2,0);
end
$$

call sp_crear_orden_compra_material();

-- SP crear orden de compra tipo 3
delimiter $$
create procedure sp_crear_orden_compra_insumo()
begin
INSERT INTO orden_compra(fecha_OC,estado_OC,tipo_OC,precio_total_OC)
VALUES (date(now()),"Pendiente",3,0);
end
$$

call sp_crear_orden_compra_insumo();


-- SP crear detalle de orden de compra tipo 1
delimiter $$
create procedure sp_ingresar_producto_orden_compra(
IN _codigo_DOCP int,
IN _cantidad_DOCP int
)
begin
declare _ID_OC int default 0;
declare _Precio_Neto float default 0;
declare _Resultado float default 0;
declare _Precio_OC float default 0;
declare _Proveedor int default 0;

select max(ID_OC) into _ID_OC from orden_compra;

select precio_total_OC into _Precio_OC from orden_compra where ID_OC=_ID_OC;

select precio_compra_producto,ID_proveedor_producto into _Precio_Neto, _Proveedor from producto where codigo_producto=_codigo_DOCP;

select  (_Precio_Neto * _cantidad_DOCP) into _Resultado;

INSERT INTO detalles_orden_compra_productos(ID_orden_DOCP,codigo_DOCP,cantidad_DOCP,ID_proveedor_DOCP)
VALUES(_ID_OC,_codigo_DOCP,_cantidad_DOCP,_Proveedor);

UPDATE orden_compra SET precio_total_OC = _Precio_OC + _Resultado  WHERE ID_OC = _ID_OC;

end
$$

 call sp_ingresar_producto_orden_compra(1,1);
 
select * from producto;
select * from orden_compra;
select * from detalles_orden_compra_productos;

-- SP crear detalle de orden de compra tipo 2
delimiter $$
create procedure sp_ingresar_material_orden_compra(
IN _codigo_DOCM int,
IN _cantidad_DOCM int
)
begin
declare _ID_OC int default 0;
declare _Precio_NetoM float default 0;
declare _ResultadoM float default 0;
declare _Precio_OC float default 0;
declare _ProveedorM int default 0;

select max(ID_OC) into _ID_OC from orden_compra;

select precio_total_OC into _Precio_OC from orden_compra where ID_OC=_ID_OC;

select precio_compra_material,ID_proveedor_material into  _Precio_NetoM, _ProveedorM from material where codigo_material=_codigo_DOCM;

select  (_Precio_NetoM * _cantidad_DOCM) into _ResultadoM;

INSERT INTO detalles_orden_compra_materiales(ID_orden_DOCM,codigo_DOCM,cantidad_DOCM,ID_proveedor_DOCM)
VALUES(_ID_OC,_codigo_DOCM,_cantidad_DOCM,_ProveedorM);

UPDATE orden_compra SET precio_total_OC = _Precio_OC + _ResultadoM  WHERE ID_OC = _ID_OC;

end
$$

 call sp_ingresar_material_orden_compra(1,1);
 
 -- SP crear detalle de orden de compra tipo 3
delimiter $$
create procedure sp_ingresar_insumo_orden_compra(
IN _codigo_DOCI int,
IN _cantidad_DOCI int
)
begin
declare _ID_OC int default 0;
declare _Precio_NetoM float default 0;
declare _ResultadoM float default 0;
declare _Precio_OC float default 0;
declare _ProveedorM int default 0;

select max(ID_OC) into _ID_OC from orden_compra;

select precio_total_OC into _Precio_OC from orden_compra where ID_OC=_ID_OC;

select precio_compra_insumo,ID_proveedor_insumo into  _Precio_NetoM, _ProveedorM from insumo where codigo_insumo=_codigo_DOCI;

select  (_Precio_NetoM * _cantidad_DOCI) into _ResultadoM;

INSERT INTO detalles_orden_compra_insumos(ID_orden_DOCI,codigo_DOCI,cantidad_DOCI,ID_proveedor_DOCI)
VALUES(_ID_OC,_codigo_DOCI,_cantidad_DOCI,_ProveedorM);

UPDATE orden_compra SET precio_total_OC = _Precio_OC + _ResultadoM  WHERE ID_OC = _ID_OC;

end
$$

 call sp_ingresar_insumo_orden_compra(1,1);


-- SP cambio estado orden compra
delimiter $$
create procedure sp_recepcion_OC(
IN _ID_OC int)
begin
UPDATE orden_compra SET estado_OC = 'Aceptado' WHERE (ID_OC = _ID_OC);
end
$$

call sp_recepcion_OC(1);

-- SP cambio estado orden compra
delimiter $$
create procedure sp_verlistaOCPendiente()
begin
select oc.ID_OC as ID_Orden,
oc.fecha_OC as Fecha,
oc.precio_total_OC as Total,
oc.estado_OC as EstadoOrden
from orden_compra oc
where estado_OC='pendiente';
end
$$

call sp_verlistaOCPendiente();

delimiter $$
create procedure sp_verResumenCostos(
IN _fechaInicial  date,
IN _fechaTermino date
)
begin

select oc.ID_OC as ID_Orden,
oc.fecha_OC as Fecha,
oc.precio_total_OC as Total,
oc.estado_OC as EstadoOrden
from orden_compra oc where oc.fecha_OC between _fechaInicial and _fechaTermino ;
end
$$

call sp_verResumenCostos('2023-06-28','2023-06-29');

delimiter $$
create procedure sp_verTotalCostos(
IN _fechaInicial date,
IN _fechaTermino date
)
begin

select
sum(oc.precio_total_OC) as Total
from orden_compra oc where oc.fecha_OC between _fechaInicial and _fechaTermino ;
end
$$

call sp_verTotalCostos('2023-06-28','2023-06-29');

DELIMITER $$
CREATE PROCEDURE sp_obtenerFechasMinMax(
    OUT min_fecha DATE,
    OUT max_fecha DATE
)
BEGIN
    SELECT MIN(fecha_OC), MAX(fecha_OC) INTO min_fecha, max_fecha FROM orden_compra;
END
$$



delimiter $$
create procedure sp_listadespachos()
begin 
select id_orden_venta as ID_Orden_Venta,
 codigo_producto as Codigo,
 nombre as Nombre,
 direccion as Direccion,
 estado as Estado,
 rut as Rut,
 precio_total as Total
from orden_de_venta
where estado = "Pendiente";
end$$

call sp_listadespachos();

delimiter $$
create procedure sp_listadespachos2()
begin 
select id_orden_venta as ID_Orden_Venta,
 codigo_producto as Codigo,
 nombre as Nombre,
 direccion as Direccion,
 estado as Estado,
 rut as Rut,
 precio_total as Total
from orden_de_venta;
end$$

call sp_listadespachos2();


delimiter $$
create procedure sp_despacho(
in _id int,
in _estado varchar(20)
)
begin
UPDATE orden_de_venta
SET
`estado` = _estado
WHERE `id_orden_venta` = _id;
end$$
call sp_despacho(2,"Despachado");


INSERT INTO orden_de_venta
(`id_orden_venta`,
`codigo_producto`,
`nombre`,
`direccion`,
`estado`,
`rut`,
`precio_total`)
VALUES
(1,1,"pedro","calle falsa 123","Pendiente","10.206.756-k",2000);


INSERT INTO orden_de_venta
(`id_orden_venta`,
`codigo_producto`,
`nombre`,
`direccion`,
`estado`,
`rut`,
`precio_total`)
VALUES
(2,1,"pedro","calle falsa 123","Pendiente","10.206.756-k",2000);

INSERT INTO orden_de_venta
(`id_orden_venta`,
`codigo_producto`,
`nombre`,
`direccion`,
`estado`,
`rut`,
`precio_total`)
VALUES
(3,1,"pedro","calle falsa 123","Pendiente","10.206.756-k",2000);

-- sp almacen niko

DELIMITER $$
CREATE PROCEDURE sp_GestAlmc_producto(
    IN _ID_almacen INT,
    IN _codigo_producto INT,
    IN _ubicacion VARCHAR(255)
)
BEGIN
    UPDATE producto SET ID_almacen_producto = _ID_almacen, ubicacion_producto = _ubicacion WHERE codigo_producto = _codigo_producto;
END $$


delimiter $$
create procedure sp_GestAlmc_material(
in _ID_almacen int,
in _codigo_material int,
in _ubicacion varchar(255)
)
begin
update material set  ID_almacen_material = _ID_almacen ,ubicacion_material=_ubicacion where codigo_material = _codigo_material ;
end
$$

delimiter $$
create procedure sp_GestAlmc_insumo(

in _ID_almacen int,
in _codigo_insumo int,
in _ubicacion varchar(255)
)
begin
update insumo set  ID_almacen_insumo = _ID_almacen,ubicacion_insumo=_ubicacion where codigo_insumo = _codigo_insumo ;
end
$$

call sp_GestAlmc_insumo(1,1,"xd");




-- benja
DELIMITER $$
CREATE PROCEDURE sp_ObtenerArticulosPorProveedor()
BEGIN
    SELECT p.ID_proveedor_producto AS ID_proveedor, pr.razonsocial AS razon_social, p.nombre_producto AS nombre_articulo, 'Producto' AS tipo, p.precio_compra_producto AS precio_compra
    FROM producto p
    INNER JOIN proveedores pr ON p.ID_proveedor_producto = pr.ID_proveedor
    UNION
    SELECT m.ID_proveedor_material, pr.razonsocial, m.nombre_material, 'Material', m.precio_compra_material
    FROM material m
    INNER JOIN proveedores pr ON m.ID_proveedor_material = pr.ID_proveedor
    UNION
    SELECT i.ID_proveedor_insumo, pr.razonsocial, i.nombre_insumo, 'Insumo', i.precio_compra_insumo
    FROM insumo i
    INNER JOIN proveedores pr ON i.ID_proveedor_insumo = pr.ID_proveedor
    ORDER BY razon_social;
END 
$$
call sp_ObtenerArticulosPorProveedor()



-- 			SP Lista producto
delimiter $$
create procedure sp_verlistaproductos_almacen()
begin
select p.codigo_producto as Codigo,
p.nombre_producto as Producto,
a.lugar as Almacen,
ubicacion_producto as Ubicacion
from producto p
left join almacen a
on p.ID_almacen_producto = ID_almacen;
end
$$

call sp_verlistaproductos_almacen()

-- procedimiento de lista materiales
delimiter $$
create procedure sp_verlistamateriales_almacen()
begin
select m.codigo_material as Codigo,
m.nombre_material as Material,
a.lugar as Almacen,
m.ubicacion_material as Ubicacion
from material m
left join almacen a
on m.ID_almacen_material = ID_almacen;
end
$$

call sp_verlistamateriales_almacen();


-- SP lista sin filtrar
delimiter $$
create procedure sp_verlistainsumos_almacen(
)
begin
select
i.codigo_insumo as Codigo,
i.nombre_insumo as Insumo,
a.lugar as Almacen,
i.ubicacion_insumo as Ubicacion
from insumo i
left join almacen a
on i.ID_almacen_insumo = ID_almacen;
end
$$

call sp_verlistainsumos_almacen();


delimiter $$
create procedure sp_verificarProducto(
IN _codigo int
)
begin
select codigo_producto from producto where  codigo_producto = _codigo;
end
$$

call sp_verificarProducto(1);

delimiter $$
create procedure sp_verificarMaterial(
IN _codigo int
)
begin
select codigo_material from material where  codigo_material = _codigo;
end
$$

call sp_verificarMaterial(1);


delimiter $$
create procedure sp_verificarInsumo(
IN _codigo int
)
begin
select codigo_insumo from insumo where  codigo_insumo = _codigo;
end
$$

call sp_verificarInsumo(1);
