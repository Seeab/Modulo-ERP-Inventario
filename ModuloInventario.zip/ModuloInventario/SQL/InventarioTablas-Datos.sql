create database sistema_erp_inventario collate utf8mb4_spanish2_ci charset utf8mb4;

use sistema_erp_inventario;

create table proveedores(
ID_proveedor int primary key,
razonsocial  varchar(255),
telefono varchar(12),
correo varchar(255)
);
create table almacen(
ID_almacen int primary key,
lugar varchar(255)
);

create table tipo_orden_compra(
ID_tipo_OC int primary key,
descripcion_tipo_OC varchar(255)
);

create table orden_compra(
ID_OC int primary key auto_increment,
fecha_OC date,
estado_OC varchar(20),
tipo_OC int,
precio_total_OC float,
FOREIGN KEY(tipo_OC) references tipo_orden_compra(ID_tipo_OC)
);

create table categoria_producto(
ID_categoria_producto int primary key,
descripcion_producto varchar(255)
);

create table categoria_material(
ID_categoria_material int primary key,
descripcion_material varchar(255)
);

create table categoria_insumo(
ID_categoria_insumo int primary key,
descripcion_insumo varchar(255)
);

create table producto(
codigo_producto int primary key,
nombre_producto varchar(255),
ID_categoria_producto int,
stock_producto int,
ID_proveedor_producto int,
ID_almacen_producto int,
ubicacion_producto varchar(255),
precio_venta_producto float,
precio_compra_producto float,
FOREIGN KEY(ID_categoria_producto) references categoria_producto(ID_categoria_producto),
FOREIGN KEY(ID_proveedor_producto) references proveedores(ID_proveedor),
FOREIGN KEY(ID_almacen_producto) references almacen(ID_almacen)
);

create table material(
codigo_material int primary key,
nombre_material varchar(255),
ID_categoria_material int,
stock_material int,
ID_proveedor_material int,
ID_almacen_material int,
ubicacion_material varchar(255),
precio_compra_material float,
FOREIGN KEY(ID_categoria_material) references categoria_material(ID_categoria_material),
FOREIGN KEY(ID_proveedor_material) references proveedores(ID_proveedor),
FOREIGN KEY(ID_almacen_material) references almacen(ID_almacen)
);

create table insumo(
codigo_insumo int primary key,
nombre_insumo varchar(255),
ID_categoria_insumo int,
stock_insumo int,
ID_proveedor_insumo int,
ID_almacen_insumo int,
ubicacion_insumo varchar(255),
precio_compra_insumo float,
FOREIGN KEY(ID_categoria_insumo) references categoria_insumo(ID_categoria_insumo),
FOREIGN KEY(ID_proveedor_insumo) references proveedores(ID_proveedor),
FOREIGN KEY(ID_almacen_insumo) references almacen(ID_almacen)
);


create table detalles_orden_compra_productos(
ID_orden_DOCP int,
codigo_DOCP int,
cantidad_DOCP int,
ID_proveedor_DOCP int,
FOREIGN KEY(ID_orden_DOCP) references orden_compra(ID_OC),
FOREIGN KEY(codigo_DOCP) references producto(codigo_producto),
FOREIGN KEY(ID_proveedor_DOCP) references proveedores(ID_proveedor)
);

create table detalles_orden_compra_materiales(
ID_orden_DOCM int,
codigo_DOCM int,
cantidad_DOCM int,
ID_proveedor_DOCM int,
FOREIGN KEY(ID_orden_DOCM) references orden_compra(ID_OC),
FOREIGN KEY(codigo_DOCM) references material(codigo_material),
FOREIGN KEY(ID_proveedor_DOCM) references proveedores(ID_proveedor)
);

create table detalles_orden_compra_insumos(
ID_orden_DOCI int,
codigo_DOCI int,
cantidad_DOCI int,
ID_proveedor_DOCI int,
FOREIGN KEY(ID_orden_DOCI) references orden_compra(ID_OC),
FOREIGN KEY(codigo_DOCI) references insumo(codigo_insumo),
FOREIGN KEY(ID_proveedor_DOCI) references proveedores(ID_proveedor)
);


-- Ventas
-- crear orden de venta 
create table orden_de_venta(
id_orden_venta int primary key,
codigo_producto int,
nombre VARCHAR(50),
direccion VARCHAR(100),
estado VARCHAR(20),
rut varchar(12),
precio_total float,
foreign key (codigo_producto) REFERENCES producto(codigo_producto)
);


-- Datos inventario
-- datos almacen 
INSERT INTO almacen(ID_almacen,lugar) VALUES(1,"Almacen 1");

INSERT INTO almacen(ID_almacen,lugar)VALUES (2,"Almacen 2");

INSERT INTO almacen(ID_almacen,lugar)VALUES (3,"Almacen 3");

-- datos proveedor
INSERT INTO proveedores(ID_proveedor,razonsocial,telefono,correo)
VALUES(1,"Ferreteria Pepito","12345678","Ferreteria_Pepito@correo.com");

INSERT INTO proveedores(ID_proveedor,razonsocial,telefono,correo)
VALUES(2,"Aserradero Juanito","12345678","Aserradero_Juanito@correo.com");

INSERT INTO proveedores(ID_proveedor,razonsocial,telefono,correo)
VALUES(3,"MicroPlay","12345678","MicroPlay@dead.com");

INSERT INTO proveedores(ID_proveedor,razonsocial,telefono,correo)
VALUES(4,"Importadora Pedrito","12345678","Importadora_Pedrito@correo.com");

-- datos categorias
INSERT INTO categoria_producto
(ID_categoria_producto,descripcion_producto) VALUES(1,"Hogar-Living");

INSERT INTO categoria_producto
(ID_categoria_producto,descripcion_producto) VALUES(2,"Hogar-Cocina");

INSERT INTO categoria_producto
(ID_categoria_producto,descripcion_producto) VALUES(3,"Hogar-Baño");

INSERT INTO categoria_producto
(ID_categoria_producto,descripcion_producto) VALUES(4,"Hogar-Dormitorio");

-- categoria materiales
INSERT INTO categoria_material
(ID_categoria_material,descripcion_material)VALUES(1,"Madera");

INSERT INTO categoria_material
(ID_categoria_material,descripcion_material)VALUES(2,"Metal");

INSERT INTO categoria_material
(ID_categoria_material,descripcion_material)VALUES(3,"Plastico");
-- categoria insumo
INSERT INTO categoria_insumo
(ID_categoria_insumo,descripcion_insumo) VALUES(1,"Oficina");

INSERT INTO categoria_insumo
(ID_categoria_insumo,descripcion_insumo) VALUES(2,"Herramientas");

INSERT INTO categoria_insumo
(ID_categoria_insumo,descripcion_insumo) VALUES(3,"Limpieza");

-- Tipo de orden de compra 
INSERT INTO tipo_orden_compra
(ID_tipo_OC,descripcion_tipo_OC)
VALUES(1,"Producto");

INSERT INTO tipo_orden_compra
(ID_tipo_OC,descripcion_tipo_OC)
VALUES(2,"Material");

INSERT INTO tipo_orden_compra
(ID_tipo_OC,descripcion_tipo_OC)
VALUES(3,"Insumo");

INSERT INTO producto
(codigo_producto,nombre_producto,ID_categoria_producto,stock_producto,ID_proveedor_producto,ID_almacen_producto,ubicacion_producto,precio_venta_producto,precio_compra_producto)
VALUES(1,"producto 1",1,4,1,1,"pasillo 1(rack 1)",3000,2000);

INSERT INTO material
(codigo_material,nombre_material,ID_categoria_material,stock_material,ID_proveedor_material,ID_almacen_material,ubicacion_material,precio_compra_material)
VALUES(1,"material 1",1,4,2,1,"pasillo 2(rack 2)",2000);

INSERT INTO insumo
(codigo_insumo,nombre_insumo,ID_categoria_insumo,stock_insumo,ID_proveedor_insumo,ID_almacen_insumo,ubicacion_insumo,precio_compra_insumo)
VALUES
(1,"insumo 1",1,4,2,1,"pasillo 2(rack 2)",2000);

-- orden de venta
INSERT INTO orden_de_venta
(id_orden_venta,codigo_producto,nombre,direccion,estado,rut,precio_total)
VALUES
(1,1,"cliente 1","calle falsa 123","Pendiente","10.206.756-k",2000);

INSERT INTO orden_de_venta
(id_orden_venta,codigo_producto,nombre,direccion,estado,rut,precio_total)
VALUES
(2,1,"cliente 2","calle falsa 123","Pendiente","10.206.756-k",2000);

INSERT INTO orden_de_venta
(id_orden_venta,codigo_producto,nombre,direccion,estado,rut,precio_total)
VALUES
(3,1,"cliente 3","calle falsa 123","Pendiente","10.206.756-k",2000);

select * from almacen;
select * from proveedores;
select * from categoria_producto;
select * from categoria_material;
select * from categoria_insumo;
select * from producto;
select * from material;
select * from insumo;
select * from tipo_orden_compra;
select * from orden_de_venta;