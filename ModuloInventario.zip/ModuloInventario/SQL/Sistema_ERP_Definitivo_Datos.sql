use sistema_erp;

-- Datos inventario
-- datos almacen 
INSERT INTO almacen(ID_almacen,lugar) VALUES(1,"Almacen 1");

INSERT INTO almacen(ID_almacen,lugar)VALUES (2,"Almacen 2");

INSERT INTO almacen(ID_almacen,lugar)VALUES (3,"Almacen 3");

-- datos proveedor
INSERT INTO proveedores(ID_proveedor,razonsocial,telefono,correo)
VALUES(1,"Ferreteria Pepito","12345678","Ferreteria_Pepito@correo.com");

INSERT INTO proveedores(ID_proveedor,razonsocial,telefono,correo)
VALUES(2,"Aserradero Juanito","12345678","Aserradero_Juanito@correo.com");

INSERT INTO proveedores(ID_proveedor,razonsocial,telefono,correo)
VALUES(3,"MicroPlay","12345678","MicroPlay@dead.com");

INSERT INTO proveedores(ID_proveedor,razonsocial,telefono,correo)
VALUES(4,"Importadora Pedrito","12345678","Importadora_Pedrito@correo.com");



-- datos categorias
INSERT INTO categoria_producto
(ID_categoria_producto,descripcion_producto) VALUES(1,"Hogar-Living");

INSERT INTO categoria_producto
(ID_categoria_producto,descripcion_producto) VALUES(2,"Hogar-Cocina");

INSERT INTO categoria_producto
(ID_categoria_producto,descripcion_producto) VALUES(3,"Hogar-Baño");

INSERT INTO categoria_producto
(ID_categoria_producto,descripcion_producto) VALUES(4,"Hogar-Dormitorio");

-- categoria materiales
INSERT INTO categoria_material
(ID_categoria_material,descripcion_material)VALUES(1,"Madera");

INSERT INTO categoria_material
(ID_categoria_material,descripcion_material)VALUES(2,"Metal");

INSERT INTO categoria_material
(ID_categoria_material,descripcion_material)VALUES(3,"Plastico");
-- categoria insumo
INSERT INTO categoria_insumo
(ID_categoria_insumo,descripcion_insumo) VALUES(1,"Oficina");

INSERT INTO categoria_insumo
(ID_categoria_insumo,descripcion_insumo) VALUES(2,"Herramientas");

INSERT INTO categoria_insumo
(ID_categoria_insumo,descripcion_insumo) VALUES(3,"Limpieza");


-- Tipo de orden de compra 
INSERT INTO tipo_orden_compra
(ID_tipo_OC,descripcion_tipo_OC)
VALUES(1,"Producto");

INSERT INTO tipo_orden_compra
(ID_tipo_OC,descripcion_tipo_OC)
VALUES(2,"Material");

INSERT INTO tipo_orden_compra
(ID_tipo_OC,descripcion_tipo_OC)
VALUES(3,"Insumo");

INSERT INTO producto
(codigo_producto,nombre_producto,ID_categoria_producto,stock_producto,ID_proveedor_producto,ID_almacen_producto,ubicacion_producto,precio_venta_producto,precio_compra_producto)
VALUES(1,"producto 1",1,4,1,1,"pasillo 1(rack 1)",3000,2000);

INSERT INTO material
(codigo_material,nombre_material,ID_categoria_material,stock_material,ID_proveedor_material,ID_almacen_material,ubicacion_material,precio_compra_material)
VALUES(1,"material 1",1,4,2,1,"pasillo 2(rack 2)",2000);

INSERT INTO insumo
(codigo_insumo,nombre_insumo,ID_categoria_insumo,stock_insumo,ID_proveedor_insumo,ID_almacen_insumo,ubicacion_insumo,precio_compra_insumo)
VALUES
(1,"insumo 1",1,4,2,1,"pasillo 2(rack 2)",2000);

select * from almacen;
select * from proveedores;
select * from categoria_producto;
select * from categoria_material;
select * from categoria_insumo;
select * from producto;
select * from material;
select * from insumo;
select * from tipo_orden_compra;

-- Datos Produccion
insert into estado_orden (descripcion)
    values ("Pendiente");
insert into estado_orden (descripcion)
    values ("En proceso");
insert into estado_orden (descripcion)
    values ("Finalizado");

Insert into tipo_mantenimiento (descripcion)
    values ("Imprevisto");
    Insert into tipo_mantenimiento (descripcion)
    values ("Rutina");
    
select * from estado_orden;
select * from tipo_mantenimiento;
    
