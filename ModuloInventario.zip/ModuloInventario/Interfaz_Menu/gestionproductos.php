<!DOCTYPE html>
<html>
    <html lang="es">
    <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <title>Gestión de productos</title>

    </head>
    <header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="menuinventario.php">Volver al Menu Inventario</a></li>
            
        <ul>
    </nav>
    </header>
<body>
<div class="contenedor-menu">
    <div class="centro-menu">
        <div class="menu">
        <h3>Gestión de productos</h3>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/ListaProductos.php'">Ver lista de productos</button>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/IngresoStockProducto.php'" >Ingresar Stock</button>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/registroproducto.php'" >Registrar producto</button> 
        </div>
    </div>
</div>
</body>
</html>