<!DOCTYPE html>
<html>
    <html lang="es">
    <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <title>Gestión de ordenes de compra</title>

    </head>
    <header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="menuinventario.php">Volver al Menu Inventario</a></li>
            
        <ul>
    </nav>
    </header>
<body>
<div class="contenedor-menu">
    <div class="centro-menu">
        <div class="menu">
        <h3>Gestión de ordenes de compra</h3>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/Crear_Orden_Compra_Producto.php'">Crear orden compra producto</button>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/Crear_Orden_Compra_Material.php'" >Crear orden compra material</button>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/Crear_Orden_Compra_Insumo.php'" >Crear orden compra insumo</button> 
        </div>
    </div>
</div>
</body>
</html>