<!DOCTYPE html>
<html>
    <html lang="es">
    <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <title>Gestion de insumos</title>

    </head>
    <header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="menuinventario.php">Volver al Menu Inventario</a></li>
            
        <ul>
    </nav>
    </header>
<body>
<div class="contenedor-menu">
    <div class="centro-menu">
        <div class="menu">
        <h3>Gestion de insumos</h3>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/ListaInsumos.php'">Ver lista de insumos</button>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/IngresoStockInsumo.php'" >Ingresar Stock</button>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/registroinsumo.php'" >Registrar Insumo</button> 
        </div>
    </div>
</div>
</body>
</html>