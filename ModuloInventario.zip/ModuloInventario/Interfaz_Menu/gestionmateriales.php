<!DOCTYPE html>
<html>
    <html lang="es">
    <head>
    <meta charset="utf-8">

    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <title>Gestion de materiales</title>
</head>
<header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="menuinventario.php">Volver al Menu Inventario</a></li>
        <ul>
    </nav>
    <h1 >Gestion de materiales</h1>
</header>
<body>
<div class="contenedor-menu">
    <div class="centro-menu">
        <div class="menu">
        <h3>Gestion de materiales</h3>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/ListaMateriales.php'">Ver lista de materiales</button>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/IngresoStockMaterial.php'" >Ingresar Stock</button>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/registromaterial.php'" >Registrar Material</button> 
        </div>
    </div>
</div>
</body>
</html>