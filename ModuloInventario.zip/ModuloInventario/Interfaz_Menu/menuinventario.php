<!DOCTYPE html>
<html>
    <html lang="es">
    <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../CSS/sistema_erp.css">
    <title>Menú Inventario</title>

    </head>
    <header>
    <nav>
        <ul>
            <li><a class="menuitem active" href="">Log In</a></li>
            
        <ul>
    </nav>
    </header>
    
<body>
<div class="contenedor-menu">
    <div class="centro-menu">
        <div class="menu">
        <h3>Menu Inventario</h3>
                <button  class="botonmenu" onclick="window.location.href='gestionproductos.php'">Gestión de productos</button>
                <button  class="botonmenu" onclick="window.location.href='gestionmateriales.php'" >Gestión de materiales</button>
                <button  class="botonmenu" onclick="window.location.href='gestioninsumos.php'" >Gestión de insumos</button>
                <button  class="botonmenu" onclick="window.location.href='gestiondespachos.php'" >Gestión de despachos</button>
                <button  class="botonmenu" onclick="window.location.href='Gestion_Orden_Compra.php'" >Gestión orden de compra</button>

                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/ListaProveedores.php'" >Proveedor y precios de compra</button>
                <button  class="botonmenu" onclick="window.location.href='ListasReabastecimiento.php'" >Listas de reabastecimiento</button>
                
            
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/ResumenCostos.php'" >Resumen de costos</button>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/Actualizar_Estado_Orden_Compra.php'" >Actualizar Estado Orden Compra</button>
                <button  class="botonmenu" onclick="window.location.href='../Interfaz_Funcion/Mover_Inventario_Almacen.php'" >Gestión de almacenes</button>
                
        </div>
    </div>
</div>

</body>
</html>